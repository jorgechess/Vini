## Muito obrigado por sua contribuição.

Antes de enviar este PR, por favor certifique-se dos seguintes items:

- [ ] Seu código é compilado de forma limpa, sem erros ou avisos.
- [ ] Você adicionou testes de unidade. Garantiu cobertura acima de 80%.
- [ ] Seu código passou pelo portal de qualidade (Sonarqube).