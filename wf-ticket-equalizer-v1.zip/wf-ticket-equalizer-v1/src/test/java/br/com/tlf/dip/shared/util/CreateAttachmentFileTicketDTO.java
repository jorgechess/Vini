package br.com.tlf.dip.shared.util;

import java.util.ArrayList;
import java.util.List;

import br.com.tlf.dip.core.domain.vo.Constants;
import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketResponseDTO;

public class CreateAttachmentFileTicketDTO {

	private CreateFlowDTO createFlowDTO = new CreateFlowDTO();

	public AttachmentFileTicketRequestDTO getAttacFileTicketRequestDTO() {
		return AttachmentFileTicketRequestDTO
				.builder()
				.flow(createFlowDTO.createFlowDTO("Tecnico", "VivoNow", "opengateway"))
				.protocol("20240416084800")
				.fileName("anexo.txt")
				.file(createFile())
				.build();		
	}

	public AttachmentFileTicketResponseDTO getAttacFileTicketResponseDTO() {
		return AttachmentFileTicketResponseDTO.builder()
				.protocol("20240416084800")
				.message(Constants.CONS_STRING_PROCESS_INSTANCE_ID + "#123456")
				.status(Constants.CONS_STRING_RESPONSE_STATUS_SUCCESS)
				.build();		
	}

	private List<String> createFile() {
		List<String> files = new ArrayList<>();
		files.add("1564651346465465432132514654654");
		return files;
	}

}
