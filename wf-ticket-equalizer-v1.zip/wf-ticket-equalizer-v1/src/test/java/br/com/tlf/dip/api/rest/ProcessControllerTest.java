package br.com.tlf.dip.api.rest;

import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;

import br.com.tlf.dip.api.rest.exception.dto.RequestFieldsValidationException;
import br.com.tlf.dip.core.port.in.ProcessService;
import br.com.tlf.dip.shared.util.CreateAttachmentFileTicketDTO;
import br.com.tlf.dip.shared.util.CreateOpenTicketDTO;
import br.com.tlf.dip.shared.util.CreateUpdateTicketDTO;

class ProcessControllerTest {

	ProcessService processService;

	ProcessController processController;
	
	String authorization;
	
	CreateOpenTicketDTO createOpenTicketDTO;
	
	CreateUpdateTicketDTO createUpdateTicketDTO;
	
	CreateAttachmentFileTicketDTO createAttachmentFileTicketDTO;
	
	@BeforeEach
	void init() {
		authorization = "Bearer 1234564";
		processService = Mockito.mock(ProcessService.class);
		processController = new ProcessController(processService );
		createOpenTicketDTO = new CreateOpenTicketDTO();
		createUpdateTicketDTO = new CreateUpdateTicketDTO();
		createAttachmentFileTicketDTO = new CreateAttachmentFileTicketDTO();
	}

	@Test
	void openTicketTest() throws Exception {

		Mockito.when(processService.start(authorization, createOpenTicketDTO.getOpenTicketRequestDTO()))
					.thenReturn(createOpenTicketDTO.getOpenTicketResponseDTO());

		assertEquals(HttpStatus.CREATED, 
				processController.openTicket(authorization, 
						createOpenTicketDTO.getOpenTicketRequestDTO()).getStatusCode());
	}

	@Test
	void openTicketErrorTest() throws Exception {

		var request = createOpenTicketDTO.getOpenTicketRequestDTO();

		request.setProtocol(null);

		Mockito.when(processService.start(authorization, request))
					.thenReturn(createOpenTicketDTO.getOpenTicketResponseDTO());
		
		Exception exception = assertThrows(RequestFieldsValidationException.class, () -> {
			processController.openTicket(authorization, 
					request).getStatusCode();
	    });

	    String expectedMessage = "Parâmetros inválidos. Os seguintes campos são obrigatórios";
	    String actualMessage = exception.getMessage();

	    assertTrue(actualMessage.contains(expectedMessage));

	}

	@Test
	void updateTicketTest() throws Exception {

		Mockito.when(processService.start(authorization, 
				createUpdateTicketDTO.getUpdateTicketRequestDTO()))
					.thenReturn(createUpdateTicketDTO.getUpdateTicketResponseDTO());

		assertEquals(HttpStatus.CREATED, 
				processController.updateTicket(authorization, 
						createUpdateTicketDTO.getUpdateTicketRequestDTO()).getStatusCode());
		
	}

	@Test
	void updateTicketErrorTest() throws Exception {

		var request = createUpdateTicketDTO.getUpdateTicketRequestDTO();

		request.setProtocol(null);

		Mockito.when(processService.start(authorization, request))
					.thenReturn(createUpdateTicketDTO.getUpdateTicketResponseDTO());
		
		Exception exception = assertThrows(RequestFieldsValidationException.class, () -> {
			processController.updateTicket(authorization, 
					request).getStatusCode();
	    });

	    String expectedMessage = "Parâmetros inválidos. Os seguintes campos são obrigatórios";
	    String actualMessage = exception.getMessage();

	    assertTrue(actualMessage.contains(expectedMessage));

	}

	@Test
	void attachmentFileTicketTest() throws Exception {

		Mockito.when(processService.start(authorization, 
				createAttachmentFileTicketDTO.getAttacFileTicketRequestDTO()))
					.thenReturn(createAttachmentFileTicketDTO.getAttacFileTicketResponseDTO());

		assertEquals(HttpStatus.CREATED, 
				processController.attachmentFileTicket(authorization, 
						createAttachmentFileTicketDTO.getAttacFileTicketRequestDTO()).getStatusCode());

	}

	@Test
	void attachmentFileTicketErrorTest() throws Exception {

		var request = createAttachmentFileTicketDTO.getAttacFileTicketRequestDTO();

		request.setProtocol(null);

		Mockito.when(processService.start(authorization, request))
					.thenReturn(createAttachmentFileTicketDTO.getAttacFileTicketResponseDTO());
		
		Exception exception = assertThrows(RequestFieldsValidationException.class, () -> {
			processController.attachmentFileTicket(authorization, 
					request).getStatusCode();
	    });

	    String expectedMessage = "Parâmetros inválidos. Os seguintes campos são obrigatórios";
	    String actualMessage = exception.getMessage();

	    assertTrue(actualMessage.contains(expectedMessage));

	}

}