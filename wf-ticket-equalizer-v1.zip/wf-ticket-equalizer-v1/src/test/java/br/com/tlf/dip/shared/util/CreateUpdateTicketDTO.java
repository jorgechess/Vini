package br.com.tlf.dip.shared.util;

import br.com.tlf.dip.core.domain.vo.Constants;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketResponseDTO;

public class CreateUpdateTicketDTO {

	private CreateFlowDTO createFlowDTO = new CreateFlowDTO();

	public UpdateTicketRequestDTO getUpdateTicketRequestDTO() {
		return UpdateTicketRequestDTO
				.builder()
				.flow(createFlowDTO.createFlowDTO("Tecnico", "VivoNow", "opengateway"))
				.protocol("20240416084800")
				.status("OPEN")
				.commentsPrivate("outros")
				.solutionCode("OK")
				.expectationDate("29/06/2024")
				.certificado("certificacao")
				.commentsPublic("Tudo OK")
				.technicalRequestNumber("252627")
				.technicalRequestProtocol("293031")
				.solutionDetail("corrigido manualmente")
				.build();		
	}

	public UpdateTicketResponseDTO getUpdateTicketResponseDTO() {
		return UpdateTicketResponseDTO.builder()
				.protocol("20240416084800")
				.message(Constants.CONS_STRING_PROCESS_INSTANCE_ID + "#123456")
				.status(Constants.CONS_STRING_RESPONSE_STATUS_SUCCESS)
				.build();		
	}

}
