package br.com.tlf.dip.shared.util;

import br.com.tlf.dip.core.domain.vo.Constants;
import br.com.tlf.dip.core.port.in.dto.AdditionalContactDTO;
import br.com.tlf.dip.core.port.in.dto.CustomerDTO;
import br.com.tlf.dip.core.port.in.dto.EquipmentDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketResponseDTO;

public class CreateOpenTicketDTO {

	private CreateFlowDTO createFlowDTO = new CreateFlowDTO();

	public OpenTicketRequestDTO getOpenTicketRequestDTO() {
		return OpenTicketRequestDTO
				.builder()
				.flow(createFlowDTO.createFlowDTO("Tecnico", "portalb2b", "opengateway"))
				.protocol("20240416084800")
				.technicalRequestProtocol("252525")
				.technicalRequestNumber("151515")
				.category("premium")
				.subCategory("senior")
				.productCatalog("Linha Movel")
				.customerType("consumer")
				.serviceOffering("ofertas")
				.expectationDate("29/06/2024")
				.description("produto final")
				.commentsPrivate("outros")
				.accessId("4125252525")
				.line("CTA-12456-013")
				.comments("produto bom")
				.customer(createCustomerDTO())
				.equipment(createEquipmentDTO())
				.origin("crm")
				.reason("venda")
				.subReason("venda de oferta")
				.build();		
	}

	public OpenTicketResponseDTO getOpenTicketResponseDTO() {
		return OpenTicketResponseDTO.builder()
				.protocol("20240416084800")
				.message(Constants.CONS_STRING_PROCESS_INSTANCE_ID + "#123456")
				.status(Constants.CONS_STRING_RESPONSE_STATUS_SUCCESS)
				.build();		
	}

	private CustomerDTO createCustomerDTO() {
		return CustomerDTO
				.builder()
				.additionalContact(createAdditionalContactDTO())
				.docNumber("4567894545")
				.caseContactEmail("email@email.com")				
				.build();
	}

	private AdditionalContactDTO createAdditionalContactDTO() {
		return AdditionalContactDTO
				.builder()
				.contactName("Fulano de Tal")
				.contactPhone("41915151515")
				.email("emai@email.com")
				.build();
	}

	private EquipmentDTO createEquipmentDTO() {
		return EquipmentDTO
				.builder()
				.address("Rua Melro")
				.hostname("teste.com.br")
				.serialNumber("NF25255")
				.build();
	}

}
