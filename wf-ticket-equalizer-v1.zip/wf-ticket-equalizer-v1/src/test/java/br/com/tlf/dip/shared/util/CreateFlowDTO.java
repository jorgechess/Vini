package br.com.tlf.dip.shared.util;

import br.com.tlf.dip.core.port.in.dto.FlowDTO;

public class CreateFlowDTO {
	
	public FlowDTO createFlowDTO(String type, String originChannel, String product) {
		return FlowDTO
				.builder()
				.type(type)
				.originChannel(originChannel)
				.product(product)
				.build();
	}

}
