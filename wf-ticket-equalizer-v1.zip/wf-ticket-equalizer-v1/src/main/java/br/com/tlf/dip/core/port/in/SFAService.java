package br.com.tlf.dip.core.port.in;

import br.com.tlf.dip.core.port.in.dto.OpenTicketResponseDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketResponseDTO;

public interface SFAService {

	OpenTicketResponseDTO openSFA(Object requestDTO);

	UpdateTicketResponseDTO updateSFA(Object requestDTO);

}
