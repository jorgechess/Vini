package br.com.tlf.dip.shared.util;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Arquitetura Corporativa
 */
public class JsonUtil {
	
	private static final Logger log = LoggerFactory.getLogger(JsonUtil.class);

	public static String objectToJson(Object obj) {

		try {
			ObjectMapper objectMapper = new ObjectMapper();
			return objectMapper.writeValueAsString(obj);
		} catch (JsonProcessingException e) {
			log.error(e.getMessage(), e);
			return null;
		}

	}

	public static <T> T jsonToObject(String json, Class<T> clazz) {

		try {
			return (T) new ObjectMapper().readValue(json, clazz);
		} catch (IOException e) {
			log.error(e.getMessage(), e);
			return null;
		}

	}
	
}