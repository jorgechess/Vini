package br.com.tlf.dip.infrasctructure.rest.vivonow.feign.archive;

import br.com.tlf.dip.infrasctructure.rest.vivonow.feign.archive.dto.VivoNowAttachmentResponseDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "vivoNowArchive", url = "${api-vivonow.url-archives}")
public interface VivoNowArchiveClient {

    @PostMapping(value = "now/attachment/file", consumes = "application/octet-stream")
    VivoNowAttachmentResponseDTO attachFile(@RequestParam("file_name") String fileName,
                                            @RequestParam("table_name") String tableName,
                                            @RequestParam("table_sys_id") String tableSysId,
                                            @RequestHeader("Authorization") String authorization,
                                            @RequestBody() byte[] file);
}
