package br.com.tlf.dip.core.port.in.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class EquipmentDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String hostname;

	@JsonProperty("serial_number")
	private String serialNumber;

	private String address;

}
