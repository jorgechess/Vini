package br.com.tlf.dip.api.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import br.com.tlf.dip.api.rest.exception.dto.RequestFieldsValidationException;
import br.com.tlf.dip.core.domain.vo.Constants;
import br.com.tlf.dip.core.domain.vo.RequestFieldsValidation;
import br.com.tlf.dip.core.port.in.ProcessService;
import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketResponseDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketResponseDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketResponseDTO;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * @author A0096617
 */
@Slf4j
@RestController
@Validated
@AllArgsConstructor
@NoArgsConstructor
@ComponentScan({"br.com.tlf.dip","br.com.vivo.camunda"})
public class ProcessController {

	@Autowired
	ProcessService processService;

	@PostMapping("/open")
	public ResponseEntity<OpenTicketResponseDTO> openTicket(
			@RequestHeader(name = "Authorization") String authorization,
					@RequestBody(required = true)  OpenTicketRequestDTO openRequestDTO) throws Exception {

		log.info("Iniciando o openTicket - Request {} ", openRequestDTO);

		var fields = new RequestFieldsValidation().validation(openRequestDTO);
		
		if (!fields.isEmpty()) {
			throw new RequestFieldsValidationException(Constants.CONS_STRING_PARAMETROS_INVALIDOS + fields);
		}

		return new ResponseEntity<>(processService.start(authorization, openRequestDTO), HttpStatus.CREATED);
	}

	@PatchMapping("/update")
	public ResponseEntity<UpdateTicketResponseDTO> updateTicket(
			@RequestHeader(name = "Authorization") String authorization,
					@RequestBody(required = true)  UpdateTicketRequestDTO updateRequestDTO) {

		log.info("Iniciando o updateTicket - Request {} ", updateRequestDTO);
		
		var fields = new RequestFieldsValidation().validation(updateRequestDTO);
		
		if (!fields.isEmpty()) {
			throw new RequestFieldsValidationException(Constants.CONS_STRING_PARAMETROS_INVALIDOS + fields);
		}
		
		return new ResponseEntity<>(processService.start(authorization, updateRequestDTO), HttpStatus.CREATED);
	}

	@PostMapping("/attachment/file")
	public ResponseEntity<AttachmentFileTicketResponseDTO> attachmentFileTicket(
			@RequestHeader(name = "Authorization") String authorization,
					@RequestBody(required = true)  AttachmentFileTicketRequestDTO attFileTicketRequestDTO) {

		log.info("Iniciando o attachmentFileTicket - Request {} ", attFileTicketRequestDTO);
		
		var fields = new RequestFieldsValidation().validation(attFileTicketRequestDTO);
		
		if (!fields.isEmpty()) {
			throw new RequestFieldsValidationException(Constants.CONS_STRING_PARAMETROS_INVALIDOS + fields);
		}

		return new ResponseEntity<>(processService.start(authorization, attFileTicketRequestDTO), HttpStatus.CREATED);
	}

}
