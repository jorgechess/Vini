package br.com.tlf.dip.infrasctructure.rest.errorrecovery.feign.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ErrorRecoveryStartDTO {

    private VariablesDTO variables;
    private String businessKey;
}
