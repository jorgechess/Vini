package br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.archive.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class AttachFilePortalB2BRequestDTO {

	private String filename;

	private String extension;

	private String mimetype;

	private String base64;

}
