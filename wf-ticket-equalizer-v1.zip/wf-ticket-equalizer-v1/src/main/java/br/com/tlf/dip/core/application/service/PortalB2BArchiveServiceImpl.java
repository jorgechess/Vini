package br.com.tlf.dip.core.application.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tlf.dip.core.application.mapper.PortalB2BMapper;
import br.com.tlf.dip.core.port.in.PortalB2BArchiveService;
import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketResponseDTO;
import br.com.tlf.dip.core.port.out.OamSvcPortOut;
import br.com.tlf.dip.core.port.out.PortalB2BArchivePortOut;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
@NoArgsConstructor
public class PortalB2BArchiveServiceImpl implements PortalB2BArchiveService {

	@Autowired
	private PortalB2BArchivePortOut portalB2BArchivePortOut;
	
	@Autowired
	private OamSvcPortOut oamSvcAdapterOut;

	@Autowired
	private PortalB2BMapper mapper;

	public AttachmentFileTicketResponseDTO attachFilePortalB2B(String authorization,
			AttachmentFileTicketRequestDTO attachmentFileTicketRequestDTO) {

		log.info("Realizando chamada de serviço da operação attachFile - PortalB2B {} ",
				attachmentFileTicketRequestDTO.getProtocol());
		
		var token = "Bearer " + oamSvcAdapterOut.getToken().getAccessToken();

		var attachFileRequest = mapper.buildAttachFilePortalB2BRequest(attachmentFileTicketRequestDTO);
		var attachFileResponse = portalB2BArchivePortOut.attachFile(attachmentFileTicketRequestDTO.getProtocol(),
				token, attachFileRequest);

		log.info("Chamada de serviço da operação attachFile finalizada - PortalB2B {} ", attachFileResponse);

		return new PortalB2BMapper().buildAttachmentFileTicketResponse(attachFileResponse);

	}

}
