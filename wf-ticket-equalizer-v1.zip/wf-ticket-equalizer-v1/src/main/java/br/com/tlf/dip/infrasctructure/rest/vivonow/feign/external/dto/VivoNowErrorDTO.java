package br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class VivoNowErrorDTO {

    public ErrorDTO error;
    public String status;
}

