package br.com.tlf.dip.infrasctructure.rest.portalb2b;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tlf.dip.core.port.out.PortalB2BArchivePortOut;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.archive.PortalB2BArchiveClient;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.archive.dto.AttachFilePortalB2BRequestDTO;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.archive.dto.AttachFilePortalB2BResponseDTO;

@Service
public class PortalB2BArchivePortOutImpl implements PortalB2BArchivePortOut {

	@Autowired
	PortalB2BArchiveClient portalB2BArchiveClient;

	@Override
	public AttachFilePortalB2BResponseDTO attachFile(String protocol, String authorization,
			AttachFilePortalB2BRequestDTO attachFilePortalB2BRequestDTO) {
		return portalB2BArchiveClient.attachFile(protocol, authorization, attachFilePortalB2BRequestDTO);
	}

}
