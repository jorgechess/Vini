package br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SubmitProducerRequestDTO {

    public VariablesDTO variables;
}
