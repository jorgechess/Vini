package br.com.tlf.dip.infrasctructure.rest.sfa.feign.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BodyResponseDTO {

	private String id;
    private Integer totalSize;
    private boolean done;
    private boolean success;
    private List<String> erros;
    private boolean created;
    private List<RecordDTO> records;
    private String errorCode;
    private String message;
}
