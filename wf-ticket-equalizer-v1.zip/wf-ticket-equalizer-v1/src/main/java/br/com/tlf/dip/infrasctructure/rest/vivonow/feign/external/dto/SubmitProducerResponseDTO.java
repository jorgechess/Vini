package br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external.dto;

import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external.dto.CreateCasePortalB2BResponseDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonProperty;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class SubmitProducerResponseDTO {

    @JsonProperty("result")
    private Result result;

    @AllArgsConstructor
    @NoArgsConstructor
    @Data
    public class Result {
        @JsonProperty("sys_id")
        public String sysId;
        @JsonProperty("number")
        public String number;
        @JsonProperty("parent_id")
        public Object parentId;
        @JsonProperty("record")
        public String record;
        @JsonProperty("redirect_portal_url")
        public String redirectPortalUrl;
        @JsonProperty("parent_table")
        public String parentTable;
        @JsonProperty("redirect_url")
        public String redirectUrl;
        @JsonProperty("table")
        public String table;
        @JsonProperty("redirect_to")
        public String redirectTo;
    }
}
