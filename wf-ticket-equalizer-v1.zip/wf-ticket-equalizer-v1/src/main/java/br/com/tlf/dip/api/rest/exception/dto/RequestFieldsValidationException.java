package br.com.tlf.dip.api.rest.exception.dto;

public class RequestFieldsValidationException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public RequestFieldsValidationException(String msg) {
		super(msg);
	}

	public RequestFieldsValidationException(String msg, Throwable cause) {
		super(msg, cause);
	}

}
