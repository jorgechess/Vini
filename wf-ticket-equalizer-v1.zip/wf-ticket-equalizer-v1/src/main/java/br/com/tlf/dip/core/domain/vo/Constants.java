package br.com.tlf.dip.core.domain.vo;

/**
 * @author A0096617
 */
public class Constants {
	
	public static final String CONS_STRING_BUSINESS_KEY = "BusinessKey";
	public static final String CONS_STRING_PROCESS_INSTANCE_ID = "ProcessInstanceId";
	public static final String CONS_STRING_RESPONSE_STATUS_SUCCESS = "Success";
	public static final String CONS_STRING_PARAMETROS_INVALIDOS = "Parâmetros inválidos. Os seguintes campos são obrigatórios: ";
	public static final String CONS_STRING_PORTALB2B_TASK = "PortalB2BTask: {} ";
	public static final String CONS_STRING_VIVONOW_TASK = "VivoNowTask: {} ";
	public static final String CONS_STRING_ERROR_NAME = "ERROR_NAME";
	public static final String CONS_STRING_ERROR_CODE = "ERROR_CODE";
	public static final String CONS_STRING_ERROR_CAUSE = "ERROR_CAUSE";
	public static final String CONS_STRING_REQUEST_ERROR = "REQUEST_ERROR";	
	public static final String CLASS_NAME_OPEN_TICKET_REQ_DTO = "OpenTicketRequestDTO";
	public static final String CLASS_NAME_UPDATE_TICKET_REQ_DTO = "UpdateTicketRequestDTO";
	public static final String CLASS_NAME_ATTACHM_FILE_TICKET_REQ_DTO = "AttachmentFileTicketRequestDTO";
	public static final String URL_COMPOSITE_REQUEST_CONTACT_REF_EMAIL = "/services/data/v58.0/query?q=select+Id+from+Contact+where+Email=";
	public static final String URL_COMPOSITE_REQUEST_CONTACT_REF_DOC = "+and+Account.BI_No_Identificador_fiscal__c=";
	public static final String URL_COMPOSITE_REQUEST_NAME_OWNER_REF = "/services/data/v58.0/query?q=select+Id,DeveloperName+from+Group+where+DeveloperName='TechnicalRequestAutomation'";
	public static final String URL_COMPOSITE_REQUEST_REC_TYPE_PROTOCOL_REF = "/services/data/v58.0/query?q=select+Id+from+recordtype+where+sobjecttype='BI_BR_Protocolo_de_Atendimento__c'+and+name='Atendimento+B2B'";
	public static final String URL_COMPOSITE_REQUEST_REC_TYPE_CASE_REF = "/services/data/v58.0/query?q=select+Id+from+recordtype+where+sobjecttype='Case'+and+name='Incidência+Técnica'";
	public static final String URL_COMPOSITE_REQUEST_ACCOUNT_REF = "/services/data/v58.0/query?q=select+Id+from+account+where+BI_No_Identificador_fiscal__c=";
	public static final String URL_COMPOSITE_REQUEST_NEW_CASE_REF = "/services/data/v58.0/sobjects/Case/";
	public static final String URL_COMPOSITE_REQUEST_PROTOCOL_REF = "/services/data/v58.0/sobjects/BI_BR_Protocolo_de_Atendimento__c";
	public static final String URL_COMPOSITE_REQUEST_COMMENT_REF = "/services/data/v58.0/sobjects/CaseComment";
	public static final String URL_COMPOSITE_REQUEST_CASE_PROTOCOL_REF = "/services/data/v58.0/query?q=select+Id+from+case+where+Protocolo__c=";
	public static final String URL_COMPOSITE_REQUEST_CASE_REF = "/services/data/v58.0/sobjects/Case/@{CaseProtocolRef.records[0].Id}";

	/*
	 * Códigos de-para do state PortalB2B
	 */
	public static final String CONS_STRING_STATE_NEW = "NEW";
	public static final String CONS_STRING_STATE_OPEN = "OPEN";
	public static final String CONS_STRING_STATE_PENDING = "PENDING";
	public static final String CONS_STRING_STATE_RESOLVED = "RESOLVED";
	public static final String CONS_STRING_STATE_CLOSED = "CLOSED";
	public static final String CONS_STRING_STATE_CANCELLED = "CANCELLED";

	/*
	 * Códigos de-para do state SFA
	 */
	public static final String CONS_STRING_STATE_EM_TRATATIVA = "EM TRATATIVA";
	public static final String CONS_STRING_STATE_AGURD_RETORNO_CLI = "AGUARDANDO RETORNO DO CLIENTE";
	public static final String CONS_STRING_STATE_ENCERRADO_PARC = "ENCERRADO PARCIALMENTE";
	public static final String CONS_STRING_STATE_RESOLVIDO = "RESOLVIDO";

	/*
	 * Códigos de-para do state VivoNow
	 */
	public static final String CONS_STRING_STATE_NOVO = "NOVO";
	public static final String CONS_STRING_STATE_EM_ANDAMENTO = "EM ANDAMENTO";
	public static final String CONS_STRING_STATE_EM_ESPERA = "EM ESPERA";
	public static final String CONS_STRING_STATE_ENCERRADO = "ENCERRADO";
	public static final String CONS_STRING_STATE_CANCELADO = "CANCELADO";

	public static final String CONS_STRING_SYS_PARAM_FIELDS = "sys_id,service,offer,failure";
	public static final String CONS_STRING_SYS_PARAM_LIMIT = "10";
	public static final String CONS_STRING_SYS_PARAM_DISPLAY_VALUE = "all";

}
