package br.com.tlf.dip.infrasctructure.rest.errorrecovery.feign.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VariablesDTO {
    private static final long serialVersionUID = 1L;

    private ProtocolDTO protocol;
    private RetryDTO retry;
    private SkipRetryDTO skipRetry;
    private FlowDTO flow;
    private OpenOnDTO openOn;
    private StackTraceDTO stackTrace;
    private StatusCodeDTO statusCode;
    private String businessKey;
}
