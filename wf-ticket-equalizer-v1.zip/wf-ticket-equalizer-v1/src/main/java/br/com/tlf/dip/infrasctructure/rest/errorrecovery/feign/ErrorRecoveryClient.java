package br.com.tlf.dip.infrasctructure.rest.errorrecovery.feign;

import br.com.tlf.dip.infrasctructure.rest.errorrecovery.feign.dto.ErrorRecoveryStartDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name="ErrorRecovery", url="${api-errorRecovery.url}")
public interface ErrorRecoveryClient {

    @PostMapping("process-definition/key/ticket-equalizer")
    public String start(
            @RequestBody ErrorRecoveryStartDTO errorRecoveryStartDTO,
            @PathVariable("start") String start);
}
