package br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonProperty;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class VariablesDTO {

    @JsonProperty("smart_token_integrated")
    private String smartTokenIntegrated;
    @JsonProperty("caller_id")
    private String callerId;
    @JsonProperty("opened_by")
    private String openedBy;
    @JsonProperty("telephone")
    private String telephone;
    @JsonProperty("customer_type")
    private String customerType;
    @JsonProperty("category")
    private String category;
    @JsonProperty("subcategory")
    private String subCategory;
    @JsonProperty("failure_detail")
    private String failureDetail;
    @JsonProperty("business_service")
    private String businessService;
    @JsonProperty("service_offering")
    private String serviceOffering;
    @JsonProperty("x_tev_sn_developme_is_there_an_operational_procedure")
    private String xTevSnDevelopmeIsThereAnOperationalProcedure;
    @JsonProperty("x_tev_sn_developme_volumetry")
    private String xTevSnDevelopmeVolumetry;
    @JsonProperty("customer_no_voice_or_no_data")
    private String customerNoVoiceOrNoData;
    @JsonProperty("x_tev_sn_developme_contingency")
    private String xTevSnDevelopmeContingency;
    @JsonProperty("line_designator_order")
    private String lineDesignatorOrder;
    @JsonProperty("cpf_cnpj")
    private String cpfCnpj;
    @JsonProperty("order")
    private String order;
    @JsonProperty("description")
    private String description;
    @JsonProperty("correlation_id")
    private String correlationId;
    @JsonProperty("correlation_display")
    private String correlationDisplay;
    @JsonProperty("scr_vendor_ticket")
    private String scrVendorTicket;
}
