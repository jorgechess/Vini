package br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import spinjar.com.fasterxml.jackson.annotation.JsonProperty;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class UpdateIncidentResponseDTO {

    @JsonProperty("result")
    public UpdateResultResponseDTO resultResponseDTO;
}
