package br.com.tlf.dip.core.port.in.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class OpenTicketRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private FlowDTO flow;

	private String protocol;

	@JsonProperty("technical_request_number")
	private String technicalRequestNumber;

	@JsonProperty("technical_request_protocol")
	private String technicalRequestProtocol;

	private CustomerDTO customer;

	private String recordTypeId;

	private String recordTypeName;

	private String category;

	private String subCategory;

	private String ownerId;

	@JsonProperty("product_catalog")
	private String productCatalog;

	private String origin;

	@JsonProperty("customer_type")
	private String customerType;

	@JsonProperty("service_offering")
	private String serviceOffering;

	@JsonProperty("case_contact_type")
	private String caseContactType;

	@JsonProperty("expectation_date")
	private String expectationDate;

	private String description;

	private String detail;

	@JsonProperty("comments_private")
	private String commentsPrivate;

	@JsonProperty("access_id")
	private String accessId;

	private String line;

	private String certificado;

	private EquipmentDTO equipment;

	private String comments;

	private String status;
	
	private String reason;
	
	private String subReason;

}