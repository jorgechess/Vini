package br.com.tlf.dip.api.process.ticketequalizer.task;

import br.com.tlf.dip.core.port.in.ErrorRecoveryService;
import br.com.tlf.dip.infrasctructure.rest.errorrecovery.feign.dto.*;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jakarta.inject.Named;
import lombok.extern.slf4j.Slf4j;

/**
 * @author A0096617
 */
@Slf4j
@Component
@Named("errorRecoveryTask")
public class ErrorRecoveryTask implements JavaDelegate {
	
	private static final String CONS_STRING_BUSINESS_KEY = "BusinessKey";

	@Autowired
	private ErrorRecoveryService errorRecoveryService;
	
	public void execute(DelegateExecution execution) throws Exception {
		
		log.info("----------------------------------");
		log.info("Iniciando o ErrorRecovery - " 
				+ CONS_STRING_BUSINESS_KEY + " {} ", 
					execution.getBusinessKey());
		
		var errorName = execution.getVariable("ERROR_NAME");
		var errorCode = execution.getVariable("ERROR_CODE");
		var errorCause = execution.getVariable("ERROR_CAUSE");
		var protocol = execution.getVariable("PROTOCOL");


		var start = "";
		var errorRecoveryStartDTO = new ErrorRecoveryStartDTO();
		var variablesDTO = new VariablesDTO();
		var protocolDTO = new ProtocolDTO();
		var skipRetryDTO = new SkipRetryDTO();
		var flowDTO = new FlowDTO();
		var openOnDTO = new OpenOnDTO();
		var stackTraceDTO = new StackTraceDTO();
		var statusCodeDTO = new StatusCodeDTO();

		protocolDTO.setValue(protocolDTO.toString());
		skipRetryDTO.setValue("false");
		flowDTO.setValue("ticket-equalizer");
		openOnDTO.setValue("");
		stackTraceDTO.setValue("");
		statusCodeDTO.setValue("");

		variablesDTO.setProtocol(protocolDTO);
		variablesDTO.setSkipRetry(skipRetryDTO);
		variablesDTO.setFlow(flowDTO);
		variablesDTO.setOpenOn(openOnDTO);
		variablesDTO.setStackTrace(stackTraceDTO);
		variablesDTO.setStatusCode(statusCodeDTO);

		errorRecoveryStartDTO.setVariables(variablesDTO);
		errorRecoveryStartDTO.setBusinessKey(execution.getBusinessKey());


		var startResponse = errorRecoveryService.start(start, errorRecoveryStartDTO);
		
		log.info("ErrorName {} ", errorName);
		log.info("ErrorCode {} ", errorCode);
		log.info("ErrorCause {} ", errorCause);
		log.info("Protocol {}", protocol);
		
		log.info("Finalizando o ErrorRecovery - " 
				+ CONS_STRING_BUSINESS_KEY + " {} ", 
					execution.getBusinessKey());
		
	}
	
}
