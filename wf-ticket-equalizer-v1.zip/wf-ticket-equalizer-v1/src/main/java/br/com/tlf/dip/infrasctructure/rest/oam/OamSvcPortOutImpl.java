package br.com.tlf.dip.infrasctructure.rest.oam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import br.com.tlf.dip.core.port.out.OamSvcPortOut;
import br.com.tlf.dip.core.port.out.dto.TokenResponseDTO;
import br.com.tlf.dip.infrasctructure.rest.oam.feign.OamSvcClient;
import br.com.tlf.dip.infrasctructure.rest.oam.feign.dto.OamBodyDTO;
import br.com.tlf.dip.shared.util.StringUtils;

@Service
public class OamSvcPortOutImpl implements OamSvcPortOut {
	
	@Autowired
	OamSvcClient client;
	
	@Value("${oam.oauth.header.authorization}")
	private String authorization;
	
	@Autowired
	private OamBodyDTO body;
	
	@Override
	@Cacheable(value = "tokenCache", key = "'token'")
	public TokenResponseDTO getToken() {
		
		var retornoToken = client.postToken(authorization, StringUtils.formatBody(body.getBody()));
		
		return retornoToken;
	}

}
