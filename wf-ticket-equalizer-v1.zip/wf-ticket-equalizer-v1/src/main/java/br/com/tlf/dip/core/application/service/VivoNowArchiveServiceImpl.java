package br.com.tlf.dip.core.application.service;

import br.com.tlf.dip.core.application.mapper.VivoNowMapper;
import br.com.tlf.dip.core.domain.vo.Constants;
import br.com.tlf.dip.core.port.in.VivoNowArchiveService;
import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketResponseDTO;
import br.com.tlf.dip.core.port.out.OamSvcPortOut;
import br.com.tlf.dip.core.port.out.VivoNowArchivePortOut;
import br.com.tlf.dip.core.port.out.VivoNowPortOut;
import br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external.dto.IncidentDTO;
import br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external.dto.ResultIncidentDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Base64;

@Service
@Slf4j
public class VivoNowArchiveServiceImpl implements VivoNowArchiveService {

    @Autowired
    private VivoNowArchivePortOut vivoNowArchivePortOut;

    @Autowired
    private VivoNowPortOut vivoNowPortOut;

    @Autowired
    private OamSvcPortOut oamSvcAdapterOut;

    @Override
    public AttachmentFileTicketResponseDTO attachFile(String authorization, AttachmentFileTicketRequestDTO attachmentFileTicketRequestDTO) {
        log.info("Realizando chamada de serviço da operação attachFile - VivoNow -> arquivo {} ", attachmentFileTicketRequestDTO.getFileName());

        var token = "Bearer " + oamSvcAdapterOut.getToken().getAccessToken();

        var sysParmQuery = "scr_vendor_ticket" + attachmentFileTicketRequestDTO.getProtocol();
        var sysParmFields = "number,state,sys_id";
        var sysParmLimit = "1";
        var sysId = "";

        var imageBytes = Base64.getDecoder().decode(attachmentFileTicketRequestDTO.getFile().get(0));



        var tableName = "incident";

        ResultIncidentDTO getSysResponse = vivoNowPortOut.getIncident(token, sysParmQuery, sysParmFields, sysParmLimit, Constants.CONS_STRING_SYS_PARAM_DISPLAY_VALUE);

        if (getSysResponse != null) {
            for (IncidentDTO result : getSysResponse.getResult()) {
                sysId = result.getSysId().getValue();
            }
        }

        var attachFileResponse = vivoNowArchivePortOut.attachFile(
                attachmentFileTicketRequestDTO.getFileName(),
                tableName,
                sysId,
                token,
                imageBytes);

        return new VivoNowMapper().buildAttachmentFileTicketResponse(attachFileResponse);
    }
}
