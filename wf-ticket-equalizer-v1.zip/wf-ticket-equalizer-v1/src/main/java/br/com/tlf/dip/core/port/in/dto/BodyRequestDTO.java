package br.com.tlf.dip.core.port.in.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(Include.NON_EMPTY)
public class BodyRequestDTO {
	
	@JsonProperty("HasProtocol__c") 
    private String hasProtocolC;
	
    @JsonProperty("RecordTypeId") 
    private String recordTypeId;
    
    @JsonProperty("AccountId") 
    private String accountId;
    
    @JsonProperty("Status") 
    private String status;
    
    @JsonProperty("Type") 
    private String type;
    
    @JsonProperty("Origin") 
    private String origin;
    
    @JsonProperty("Subcategory__c") 
    private String subcategoryC;
    
    @JsonProperty("Product__c") 
    private String productC;
    
    @JsonProperty("Reason__c") 
    private String reasonC;
    
    @JsonProperty("Subreason__c") 
    private String subReasonC;
    
    @JsonProperty("Description") 
    private String description;
    
    @JsonProperty("ContactId") 
    private String contactId;
    
    @JsonProperty("OwnerId") 
    private String ownerId;
    
    @JsonProperty("TechnicalRequestNumber__c") 
    private String technicalRequestNumberC;
    
    @JsonProperty("TechnicalProtocolNumber__c") 
    private String technicalProtocolNumberC;
    
    @JsonProperty("Caso__c") 
    private String casoC;
    
    @JsonProperty("Origem_Protocolo__c") 
    private String origemProtocoloC;
    
    @JsonProperty("Name") 
    private Long name;
    
    @JsonProperty("ParentId") 
    private String parentId;
    
    @JsonProperty("CommentBody") 
    private String commentBody;
    
    @JsonProperty("Solution__c") 
    private String solutionC;
    
    @JsonProperty("SolutionDetail__c") 
    private String solutionDetailC;
    
    @JsonProperty("Title") 
    private String title;
    
    @JsonProperty("PathOnClient") 
    private String pathOnClient;
    
    @JsonProperty("VersionData") 
    private String versionData;
    
    @JsonProperty("ContentDocumentId") 
    private String contentDocumentId;
    
    @JsonProperty("LinkedEntityId") 
    private String linkedEntityId;
    
    @JsonProperty("Visibility") 
    private String visibility;

}
