package br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class EditCasePortalB2BRequestDTO {

	private String state;

	@JsonProperty("work_notes")
	private String workNotes;

	@JsonProperty("resolution_code")
	private String resolutionCode;

	@JsonProperty("close_notes")
	private String closeNotes;

	@JsonProperty("u_pending_reason")
	private String uPendingReason;

	@JsonProperty("u_data_resposta_certificacao")
	private String uDataRespostaCertificacao;

	@JsonProperty("u_certificado")
	private String uCertificado;

	private String comments;

}
