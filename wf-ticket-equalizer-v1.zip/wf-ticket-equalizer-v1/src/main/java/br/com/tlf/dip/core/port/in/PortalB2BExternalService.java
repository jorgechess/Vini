package br.com.tlf.dip.core.port.in;

import br.com.tlf.dip.core.port.in.dto.OpenTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketResponseDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketResponseDTO;

public interface PortalB2BExternalService {

	OpenTicketResponseDTO createCasePortalB2B(String authorization, 
			OpenTicketRequestDTO openTicketRequestDTO);

	UpdateTicketResponseDTO editCasePortalB2B(String authorization, 
			UpdateTicketRequestDTO updateTicketRequestDTO);

}
