package br.com.tlf.dip;

import org.camunda.bpm.spring.boot.starter.annotation.EnableProcessApplication;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;

/**
 * @author Arquitetura Corporativa
*/
@SpringBootApplication
@ComponentScan({"br.com.tlf.dip","br.com.vivo.camunda"})
@EnableProcessApplication("wf-ticket-equalizer-v1")
@EnableFeignClients
public class ProcessApp {
	public static void main(String... args) {
		SpringApplication.run(ProcessApp.class, args);
	}
}