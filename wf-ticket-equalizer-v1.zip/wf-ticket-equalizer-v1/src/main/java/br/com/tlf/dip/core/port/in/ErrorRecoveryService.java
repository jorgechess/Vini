package br.com.tlf.dip.core.port.in;

import br.com.tlf.dip.infrasctructure.rest.errorrecovery.feign.dto.ErrorRecoveryStartDTO;

public interface ErrorRecoveryService {

    String start(String start, ErrorRecoveryStartDTO errorRecoveryStartDTO);
}
