package br.com.tlf.dip.api.process.ticketequalizer.task;

import br.com.tlf.dip.core.port.in.VivoNowArchiveService;
import br.com.tlf.dip.core.port.in.VivoNowService;
import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketRequestDTO;
import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import br.com.tlf.dip.core.domain.vo.Constants;
import br.com.tlf.dip.core.domain.vo.ProcessEnum;
import lombok.extern.slf4j.Slf4j;

/**
 * @author A0096617
 */
@Slf4j
@Component
@Service("vivoNowTask")
public class VivoNowTask implements JavaDelegate {
	
	private static final String CONS_STRING_BUSINESS_KEY = "BusinessKey";

	@Autowired
	private VivoNowService vivoNowService;

	@Autowired
	private VivoNowArchiveService vivoNowArchiveService;

	@Override
	public void execute(DelegateExecution execution) throws Exception {

		log.info("----------------------------------");
		log.info("Iniciando o VivoNowTask - " 
				+ CONS_STRING_BUSINESS_KEY + " {} " 
					+ execution.getBusinessKey());
		
		var requestDTO = execution.getVariable(ProcessEnum.WF_VAR_REQUEST_DTO.getValue());
		var authorization = execution.getVariable(ProcessEnum.WF_VAR_AUTHORIZATION.getValue());

		switch (requestDTO.getClass().getSimpleName()) {
		  case (Constants.CLASS_NAME_OPEN_TICKET_REQ_DTO):
			  log.info("VivoNowTask - OpenTicketRequestDTO: " + requestDTO);

			  try {
				  var submitProducerResponseDTO =  vivoNowService.createCaseVivoNow((String)authorization, (OpenTicketRequestDTO) requestDTO);
				  execution.setVariable(ProcessEnum.WF_VAR_VIVO_NOW_RESPONSE_DTO.getValue(), submitProducerResponseDTO);
				  log.info(Constants.CONS_STRING_VIVONOW_TASK, submitProducerResponseDTO);
			  } catch (Exception e) {
				  log.error("Erro na executação do VivoNowTask-OpenTicket ", e);
				  execution.setVariable(Constants.CONS_STRING_ERROR_NAME, Constants.CONS_STRING_REQUEST_ERROR);
				  execution.setVariable(Constants.CONS_STRING_ERROR_CODE, Constants.CONS_STRING_REQUEST_ERROR);
				  execution.setVariable(Constants.CONS_STRING_ERROR_CAUSE, e.toString());
				  throw new BpmnError(Constants.CONS_STRING_REQUEST_ERROR, Constants.CONS_STRING_REQUEST_ERROR, e.getCause());
		  }
		  
		  break;
		  case (Constants.CLASS_NAME_UPDATE_TICKET_REQ_DTO):
			  log.info("VivoNowTask - UpdateTicketRequestDTO: " + requestDTO);

			  try {
				  var updateTicketResponse = vivoNowService.updateCaseVivoNow((String)authorization, (UpdateTicketRequestDTO) requestDTO);
				  execution.setVariable(ProcessEnum.WF_VAR_VIVO_NOW_RESPONSE_DTO.getValue(), updateTicketResponse);
				  log.info(Constants.CONS_STRING_VIVONOW_TASK, updateTicketResponse);

			  } catch (Exception e) {
				  log.error("Erro na executação do VivoNowTask-UpdateTicket ", e);
				  execution.setVariable(Constants.CONS_STRING_ERROR_NAME, Constants.CONS_STRING_REQUEST_ERROR);
				  execution.setVariable(Constants.CONS_STRING_ERROR_CODE, Constants.CONS_STRING_REQUEST_ERROR);
				  execution.setVariable(Constants.CONS_STRING_ERROR_CAUSE, e.toString());
				  throw new BpmnError(Constants.CONS_STRING_REQUEST_ERROR, Constants.CONS_STRING_REQUEST_ERROR, e.getCause());
			  }
		  
		  break;
		  case (Constants.CLASS_NAME_ATTACHM_FILE_TICKET_REQ_DTO):
			  log.info("VivoNowTask - AttachmentFileTicketRequestDTO: " + requestDTO);

			  try {
				  var attachFileResponse = vivoNowArchiveService.attachFile((String)authorization, (AttachmentFileTicketRequestDTO) requestDTO);
				  execution.setVariable(ProcessEnum.WF_VAR_VIVO_NOW_RESPONSE_DTO.getValue(), attachFileResponse);
				  log.info(Constants.CONS_STRING_VIVONOW_TASK, attachFileResponse);
			  } catch (Exception e) {
				  log.error("Erro na executação do VivoNowTask-AttachFile ", e);
				  execution.setVariable(Constants.CONS_STRING_ERROR_NAME, Constants.CONS_STRING_REQUEST_ERROR);
				  execution.setVariable(Constants.CONS_STRING_ERROR_CODE, Constants.CONS_STRING_REQUEST_ERROR);
				  execution.setVariable(Constants.CONS_STRING_ERROR_CAUSE, e.toString());
				  throw new BpmnError(Constants.CONS_STRING_REQUEST_ERROR, Constants.CONS_STRING_REQUEST_ERROR, e.getCause());
			  }

		  break;
		  default:
			  log.info("VivoNowTask - Do nothing: " + requestDTO);
		  break;
		}

		log.info("Finalizando o VivoNowTask - " 
				+ CONS_STRING_BUSINESS_KEY 
					+ " {} " + execution.getBusinessKey());

	}

}