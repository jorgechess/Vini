package br.com.tlf.dip.core.port.in.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class AdditionalContactDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String email;

	@JsonProperty("contact_name")
	private String contactName;

	@JsonProperty("contact_phone")
	private String contactPhone;

}
