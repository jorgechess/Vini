package br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class CreateCasePortalB2BRequestDTO {
	
	@JsonProperty("contact_type")
	private String contactType;

	private String cnpj;

	@JsonProperty("u_protocolo_vivonet")
	private String uProtocoloVivonet;

	private String email;

	private String description;

	@JsonProperty("work_notes")
	private String workNotes;

	@JsonProperty("short_description")
	private String shortDescription;

	@JsonProperty("service_offering")
	private String serviceOffering;

	@JsonProperty("u_additional_contact_email")	
	private String uAdditionalContactEmail;

	@JsonProperty("u_additional_contact_name")	
	private String uAdditionalContactName;

	@JsonProperty("u_additional_contact_phone")	
	private String uAdditionalContactPhone;
	
	@JsonProperty("u_business_hour")
	private String uBusinessHour;

	@JsonProperty("u_access_id")
	private String uAccessId;	
	
	@JsonProperty("u_line")
	private String uLine;
	
	@JsonProperty("u_hostname")
	private String uHostname;
	
	@JsonProperty("u_serial_number")
	private String uSerialNumber;
	
	@JsonProperty("u_endereco")
	private String uEndereco;
	
	@JsonProperty("comments")
	private String comments;

	@JsonProperty("category")
	private String category;

	@JsonProperty("subcategory")
	private String subcategory;

	@JsonProperty("business_service")
	private String businessService;

	private String state;

	private String number;

	@JsonProperty("u_number_sigitm")
	private String uNumberSigitm;

}
