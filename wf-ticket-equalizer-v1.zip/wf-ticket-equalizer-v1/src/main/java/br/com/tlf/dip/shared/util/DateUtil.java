package br.com.tlf.dip.shared.util;

import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;

/**
 * @author A0096617
 */
public class DateUtil {

	public String getTimestamp() {
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
		return formatter.format(timestamp.toLocalDateTime());
	}

}
