package br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external.dto.CreateCasePortalB2BRequestDTO;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external.dto.CreateCasePortalB2BResponseDTO;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external.dto.EditCasePortalB2BRequestDTO;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external.dto.EditCasePortalB2BResponseDTO;

@FeignClient(name = "portalB2BExternal", url = "${portalB2BExternal.url}")
public interface PortalB2BExternalClient {

    @PostMapping("/api/og/opengateway/create")
    CreateCasePortalB2BResponseDTO createCase(
            @RequestHeader("Authorization") String authorization,
            @RequestBody CreateCasePortalB2BRequestDTO createCasePortalB2BRequestDTO);

    @PatchMapping("/api/og/opengateway/{vivonet}/edit")
    EditCasePortalB2BResponseDTO editCase(
    		@PathVariable("vivonet") String protocol,
            @RequestHeader("Authorization") String authorization,
            @RequestBody EditCasePortalB2BRequestDTO editCasePortalB2BRequestDTO);

}
