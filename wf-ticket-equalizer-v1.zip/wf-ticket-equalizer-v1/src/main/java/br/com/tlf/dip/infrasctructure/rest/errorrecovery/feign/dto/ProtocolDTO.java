package br.com.tlf.dip.infrasctructure.rest.errorrecovery.feign.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProtocolDTO {
    private String value;
    private String type;
}
