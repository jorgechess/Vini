package br.com.tlf.dip.shared.util;

import java.util.Locale;

import br.com.tlf.dip.core.domain.vo.Constants;

public class StateUtil {
	
	public String getPortalB2BState(String state) {

		String statePortalB2B;

		switch (state.toUpperCase(new Locale("pt", "BR"))) {
		  /*
		   * Códigos de-para origem PortalB2B
		   */
		  case (Constants.CONS_STRING_STATE_NEW):
			  statePortalB2B = "1";
		  break;
		  case (Constants.CONS_STRING_STATE_OPEN):
			  statePortalB2B = "10";		  
		  break;
		  case (Constants.CONS_STRING_STATE_PENDING):
			  statePortalB2B = "-5";		  
		  break;
		  case (Constants.CONS_STRING_STATE_RESOLVED):
			  statePortalB2B = "6";			  
		  break;
		  case (Constants.CONS_STRING_STATE_CLOSED):
			  statePortalB2B = "3";			  
	      break;
		  case (Constants.CONS_STRING_STATE_CANCELLED):
			  statePortalB2B = "7";			  
		  break;

		  /*
		   * Códigos de-para origem SFA
		   */
		  case (Constants.CONS_STRING_STATE_EM_TRATATIVA):
			  statePortalB2B = "10";		  
		  break;
		  case (Constants.CONS_STRING_STATE_AGURD_RETORNO_CLI):
			  statePortalB2B = "-5";		  
		  break;
		  case (Constants.CONS_STRING_STATE_ENCERRADO_PARC):
			  statePortalB2B = "6";			  
		  break;

		  /*
		   * Códigos de-para origem VivoNow
		   */
		  case (Constants.CONS_STRING_STATE_NOVO):
			  statePortalB2B = "1";
		  break;
		  case (Constants.CONS_STRING_STATE_EM_ANDAMENTO):
			  statePortalB2B = "10";		  
		  break;
		  case (Constants.CONS_STRING_STATE_EM_ESPERA):
			  statePortalB2B = "-5";		  
		  break;
		  case (Constants.CONS_STRING_STATE_RESOLVIDO):
			  statePortalB2B = "6";			  
	      break;
		  case (Constants.CONS_STRING_STATE_ENCERRADO):
			  statePortalB2B = "3";			  
	      break;
		  case (Constants.CONS_STRING_STATE_CANCELADO):
			  statePortalB2B = "7";			  
		  break;		
		  
		  default:			  
			  statePortalB2B = "";			  
		  break;
		}		
		return statePortalB2B;
	}

}
