package br.com.tlf.dip.infrasctructure.rest.sfa.feign.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RecordDTO {
	
	private AttributesDTO attributes;
    @JsonProperty("Id") 
    private String id;

}
