package br.com.tlf.dip.infrasctructure.rest.oam.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import br.com.tlf.dip.core.port.out.dto.TokenResponseDTO;

@FeignClient(name = "api-oam", url = "${oam.oauth.endpoint.url}")
public interface OamSvcClient {
	
	@PostMapping(consumes = "application/x-www-form-urlencoded;charset=UTF-8")
	public TokenResponseDTO postToken(@RequestHeader("Authorization") String authorization,
													@RequestBody String requestToken);

}
