package br.com.tlf.dip.infrasctructure.rest.vivonow;

import br.com.tlf.dip.core.port.out.VivoNowPortOut;
import br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external.VivoNowClient;
import br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external.dto.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VivoNowPortOutImpl implements VivoNowPortOut {

    @Autowired
    VivoNowClient client;

    @Override
    public SubmitProducerResponseDTO submitProducer(String authorization, SubmitProducerRequestDTO submitProducerRequestDTO){
        return client.submitProducer(authorization, submitProducerRequestDTO);
    }

    @Override
    public GetAllResponseDTO getAll(String authorization, String sysParamQuery, String sysParmFields, String sysParmLimit, String sysParmDisplayValue) {
        return client.getAll(authorization, sysParamQuery, sysParmFields, sysParmLimit, sysParmDisplayValue);
    }

    @Override
    public UpdateIncidentResponseDTO updateIncident(String authorization, String incidentId, UpdateIncidentRequestDTO updateIncidentRequestDTO) {
        return client.updateIncident(authorization, incidentId, updateIncidentRequestDTO);
    }

    @Override
    public ResultIncidentDTO getIncident(String authorization, String sysParamQuery, String sysParmFields, String sysParmLimit, String sysParmDisplayValue) {
        return client.getIncident(authorization, sysParamQuery, sysParmFields, sysParmLimit, sysParmDisplayValue);
    }
}
