package br.com.tlf.dip.infrasctructure.rest.portalb2b;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tlf.dip.core.port.out.PortalB2BExternalPortOut;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external.PortalB2BExternalClient;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external.dto.CreateCasePortalB2BRequestDTO;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external.dto.CreateCasePortalB2BResponseDTO;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external.dto.EditCasePortalB2BRequestDTO;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external.dto.EditCasePortalB2BResponseDTO;

@Service
public class PortalB2BExternalPortOutImpl implements PortalB2BExternalPortOut {

	@Autowired
	PortalB2BExternalClient portalB2BExternalClient;

	@Override
	public CreateCasePortalB2BResponseDTO createCase(String authorization,
			CreateCasePortalB2BRequestDTO createCasePortalB2BRequestDTO) {
		return portalB2BExternalClient.createCase(authorization, createCasePortalB2BRequestDTO);
	}

	@Override
	public EditCasePortalB2BResponseDTO editCase(String protocol, String authorization,
			EditCasePortalB2BRequestDTO editCasePortalB2BRequestDTO) {
		return portalB2BExternalClient.editCase(protocol, authorization, editCasePortalB2BRequestDTO);
	}

}
