package br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ResultDTO{
    @JsonProperty("offer")
    private ResultTypeDTO offer;
    @JsonProperty("sys_id")
    private ResultTypeDTO sysId;
    @JsonProperty("service")
    private ResultTypeDTO service;
    @JsonProperty("failure")
    private ResultTypeDTO failure;
}
