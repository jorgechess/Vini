package br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class CreateCasePortalB2BResponseDTO {

	@JsonProperty("result")
	private Result result;

	@AllArgsConstructor
	@NoArgsConstructor
	@Data
	public class Result {

		@JsonProperty("type")
		private String type;

		@JsonProperty("title")
		private String title;

		@JsonProperty("message")
		private String message;

		@JsonProperty("success")
		private String success;

		@JsonProperty("case_id")
		private String caseId;

	}

}
