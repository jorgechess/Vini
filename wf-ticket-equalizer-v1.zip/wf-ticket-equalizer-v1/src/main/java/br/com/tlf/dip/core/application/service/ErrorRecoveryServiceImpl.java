package br.com.tlf.dip.core.application.service;

import br.com.tlf.dip.core.port.in.ErrorRecoveryService;
import br.com.tlf.dip.core.port.out.ErrorRecoveryPortOut;
import br.com.tlf.dip.infrasctructure.rest.errorrecovery.feign.dto.ErrorRecoveryStartDTO;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@AllArgsConstructor
@NoArgsConstructor
public class ErrorRecoveryServiceImpl implements ErrorRecoveryService {

    @Autowired
    private ErrorRecoveryPortOut errorRecoveryPortOut;

    @Override
    public String start(String start, ErrorRecoveryStartDTO errorRecoveryStartDTO){

        log.info("Iniciando Error Recovery");

        var startResponse = errorRecoveryPortOut.start(start, errorRecoveryStartDTO);

        log.info("Chamada de serviço da operação ErrorRecovery finalizada - {} ", startResponse);

        return new String(startResponse);
    }
}
