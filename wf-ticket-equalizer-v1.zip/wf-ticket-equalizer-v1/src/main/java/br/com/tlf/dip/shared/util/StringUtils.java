package br.com.tlf.dip.shared.util;

import br.com.tlf.dip.core.port.in.dto.OpenTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketRequestDTO;
import br.com.tlf.dip.infrasctructure.rest.oam.feign.dto.BodyDTO;

public class StringUtils {

	public static String formatURLString(OpenTicketRequestDTO request, String... strings) {

		if (strings.length == 1)
			return strings[0] + "'" + request.getCustomer().getDocNumber() + "'";
		else
			return strings[0] + "'" + request.getCustomer().getCaseContactEmail() + "'" + strings[1] + "'"
					+ request.getCustomer().getDocNumber() + "'";

	}

	public static String formatURLString(UpdateTicketRequestDTO request, String url) {

		return url + "'" + request.getProtocol() + "'";

	}
	
	public static String formatBody (BodyDTO params) {
		return "grant_type=" + params.getGrantType() + "&username=" + params.getUsername() + "&password=" + params.getPassword() + "&scope=" + params.getScope();
	}

}
