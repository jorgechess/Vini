package br.com.tlf.dip.infrasctructure.rest.oam.feign.dto;

import lombok.Data;

@Data
public class BodyDTO {

	private String grantType;
	private String scope;
	private String username;
	private String password;
}
