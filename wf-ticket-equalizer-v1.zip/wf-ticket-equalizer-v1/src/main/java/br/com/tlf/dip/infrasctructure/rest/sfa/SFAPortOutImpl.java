package br.com.tlf.dip.infrasctructure.rest.sfa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import br.com.tlf.dip.core.port.out.SFAPortOut;
import br.com.tlf.dip.infrasctructure.rest.sfa.feign.SFAClient;
import br.com.tlf.dip.infrasctructure.rest.sfa.feign.dto.RequestSFADTO;
import br.com.tlf.dip.infrasctructure.rest.sfa.feign.dto.ResponseSFADTO;

@Service
public class SFAPortOutImpl implements SFAPortOut {
	
	@Autowired
	private SFAClient client;
	
	@Value("${api-sfa.iss}")
	private String iss;
	
	@Override
	public ResponseSFADTO openSFA(RequestSFADTO requestSFADTO, String token) {
		return client.openSFA(requestSFADTO, token, iss);
	}

	@Override
	public ResponseSFADTO updateSFA(RequestSFADTO requestSFADTO, String token) {
		return client.updateSFA(requestSFADTO, token, iss);
	}

}
