package br.com.tlf.dip.api.rest.exception.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class CustomError implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("_errorCode")
	private Integer errorCode;
	
	@JsonProperty("_message")
	private String message;
	
	@JsonProperty("_details")
	private String details;
	
	@JsonProperty("_timestamp")
	private String timestamp;
	
	@JsonProperty("_traceId")
	private String traceId;
	
	@JsonProperty("_errors")
	private List<ErrorDetail> errors;

}
