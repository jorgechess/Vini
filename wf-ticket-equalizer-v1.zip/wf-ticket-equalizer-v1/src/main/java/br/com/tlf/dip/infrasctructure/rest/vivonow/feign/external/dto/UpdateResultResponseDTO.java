package br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UpdateResultResponseDTO {

    private String number;
}
