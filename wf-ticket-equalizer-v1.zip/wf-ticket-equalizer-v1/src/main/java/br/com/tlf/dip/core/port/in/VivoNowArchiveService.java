package br.com.tlf.dip.core.port.in;

import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketResponseDTO;
import br.com.tlf.dip.infrasctructure.rest.vivonow.feign.archive.dto.VivoNowAttachmentResponseDTO;
import org.springframework.web.multipart.MultipartFile;

public interface VivoNowArchiveService {

    AttachmentFileTicketResponseDTO attachFile(String authorization,
                                               AttachmentFileTicketRequestDTO attachmentFileTicketRequestDTO);
}
