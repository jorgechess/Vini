package br.com.tlf.dip.api.process.ticketequalizer.task;

import org.camunda.bpm.engine.delegate.BpmnError;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.tlf.dip.core.domain.vo.Constants;
import br.com.tlf.dip.core.domain.vo.ProcessEnum;
import br.com.tlf.dip.core.port.in.PortalB2BArchiveService;
import br.com.tlf.dip.core.port.in.PortalB2BExternalService;
import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketRequestDTO;
import jakarta.inject.Named;
import lombok.extern.slf4j.Slf4j;

/**
 * @author A0096617
 */
@Slf4j
@Component
@Named("portalB2BTask")
public class PortalB2BTask implements JavaDelegate {

	@Autowired
	private PortalB2BExternalService portalB2BExternalService;
	
	@Autowired
	private PortalB2BArchiveService portalB2BArchiveService;

	@Override
	public void execute(DelegateExecution execution) throws Exception {

		log.info("----------------------------------");
		log.info("Iniciando o PortalB2BTask - " 
				+ Constants.CONS_STRING_BUSINESS_KEY + " {} ", 
					execution.getBusinessKey());

		var requestDTO = execution.getVariable(ProcessEnum.WF_VAR_REQUEST_DTO.getValue());
		var authorization = execution.getVariable(ProcessEnum.WF_VAR_AUTHORIZATION.getValue());

		switch (requestDTO.getClass().getSimpleName()) {
		  case (Constants.CLASS_NAME_OPEN_TICKET_REQ_DTO):

			  try {
				  log.info("PortalB2BTask-OpenTicket {} ", requestDTO);
				  var portalB2BresponseDTO = portalB2BExternalService.createCasePortalB2B((String)authorization, (OpenTicketRequestDTO) requestDTO);
				  execution.setVariable(ProcessEnum.WF_VAR_PORTAL_B2B_RESPONSE_DTO.getValue(), portalB2BresponseDTO);
				  log.info(Constants.CONS_STRING_PORTALB2B_TASK, portalB2BresponseDTO);
			} catch (Exception e) {
				log.error("Erro na executação do PortalB2BTask-OpenTicket ", e);
				execution.setVariable(Constants.CONS_STRING_ERROR_NAME, Constants.CONS_STRING_REQUEST_ERROR);
				execution.setVariable(Constants.CONS_STRING_ERROR_CODE, Constants.CONS_STRING_REQUEST_ERROR);
				execution.setVariable(Constants.CONS_STRING_ERROR_CAUSE, e.toString());
				throw new BpmnError(Constants.CONS_STRING_REQUEST_ERROR, Constants.CONS_STRING_REQUEST_ERROR, e.getCause());
			}
  
		  break;
		  case (Constants.CLASS_NAME_UPDATE_TICKET_REQ_DTO):
			  
			  try {
				  log.info("PortalB2BTask-UpdateTicket {} ", requestDTO);
				  var portalB2BresponseDTO = portalB2BExternalService.editCasePortalB2B((String)authorization, (UpdateTicketRequestDTO) requestDTO);
			  	  execution.setVariable(ProcessEnum.WF_VAR_PORTAL_B2B_RESPONSE_DTO.getValue(), portalB2BresponseDTO);
			  	  log.info(Constants.CONS_STRING_PORTALB2B_TASK, portalB2BresponseDTO);
			} catch (Exception e) {
				log.error("Erro na executação do PortalB2BTask-UpdateTicket ", e);
				execution.setVariable(Constants.CONS_STRING_ERROR_NAME, Constants.CONS_STRING_REQUEST_ERROR);
				execution.setVariable(Constants.CONS_STRING_ERROR_CODE, Constants.CONS_STRING_REQUEST_ERROR);
				execution.setVariable(Constants.CONS_STRING_ERROR_CAUSE, e.toString());
				throw new BpmnError(Constants.CONS_STRING_REQUEST_ERROR, Constants.CONS_STRING_REQUEST_ERROR, e.getCause());
			}			  
  
		  break;
		  case (Constants.CLASS_NAME_ATTACHM_FILE_TICKET_REQ_DTO):
			  
			  try {
				  log.info("PortalB2BTask-AttachmentFileTicket {} ", requestDTO);
				  var portalB2BresponseDTO = portalB2BArchiveService.attachFilePortalB2B((String)authorization, (AttachmentFileTicketRequestDTO) requestDTO);
				  execution.setVariable(ProcessEnum.WF_VAR_PORTAL_B2B_RESPONSE_DTO.getValue(), portalB2BresponseDTO);
				  log.info(Constants.CONS_STRING_PORTALB2B_TASK, portalB2BresponseDTO);
			} catch (Exception e) {
				log.error("Erro na executação do PortalB2BTask-AttachmentFileTicket ", e);
				execution.setVariable(Constants.CONS_STRING_ERROR_NAME, Constants.CONS_STRING_REQUEST_ERROR);
				execution.setVariable(Constants.CONS_STRING_ERROR_CODE, Constants.CONS_STRING_REQUEST_ERROR);
				execution.setVariable(Constants.CONS_STRING_ERROR_CAUSE, e.toString());

				throw new BpmnError(Constants.CONS_STRING_REQUEST_ERROR, Constants.CONS_STRING_REQUEST_ERROR, e.getCause());
			}			  
  
		  break;
		  default:
			  log.info("PortalB2BTask - Do nothing {} ", requestDTO);			  
		  break;
		}

		log.info("Finalizando o PortalB2BTask - " 
				+ Constants.CONS_STRING_BUSINESS_KEY + " {} ", 
					execution.getBusinessKey());

	}

}