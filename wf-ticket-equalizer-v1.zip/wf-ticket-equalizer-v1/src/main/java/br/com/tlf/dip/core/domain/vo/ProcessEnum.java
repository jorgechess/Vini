package br.com.tlf.dip.core.domain.vo;

/**
 * @author A0096617
 */
public enum ProcessEnum {

	WF_NAME_TICKET_EQUALIZER("TicketEqualizer"),
	WF_VAR_CHAMADO_TYPE("chamadoType"),
	WF_VAR_ORIGIN_CHANNEL("originChannel"),
	WF_VAR_PRODUCT("product"),
	WF_VAR_REQUEST_DTO("requestDTO"),
	WF_VAR_PORTAL_B2B_RESPONSE_DTO("portalB2BresponseDTO"),
	WF_VAR_VIVO_NOW_RESPONSE_DTO("vivoNowResponseDTO"),
	WF_VAR_AUTHORIZATION("authorization"),
	WF_VAR_PROTOCOL("protocol");

	private final String value;

	ProcessEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }

}
