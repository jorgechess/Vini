package br.com.tlf.dip.api.rest.exception.dto;

public class InvalidRequestSFAException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public InvalidRequestSFAException(String msg) {
		super(msg);
	}

	public InvalidRequestSFAException(String msg, Throwable cause) {
		super(msg, cause);
	}

}
