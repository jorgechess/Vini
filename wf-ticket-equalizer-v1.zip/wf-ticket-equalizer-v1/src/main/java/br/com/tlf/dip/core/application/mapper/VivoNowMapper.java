package br.com.tlf.dip.core.application.mapper;

import br.com.tlf.dip.core.port.in.dto.*;
import br.com.tlf.dip.infrasctructure.rest.vivonow.feign.archive.dto.VivoNowAttachmentResponseDTO;
import br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external.dto.*;
import org.springframework.stereotype.Component;

@Component
public class VivoNowMapper {

    public SubmitProducerRequestDTO buildSubmitProducerVivoNowRequest(OpenTicketRequestDTO openTicketRequestDTO) {
        var variables =
                VariablesDTO
                        .builder()
                        .correlationId(openTicketRequestDTO.getFlow().getOriginChannel() == "portalB2B"? "B2B Open Gateway" : "CRM Open Gateway")
                        .correlationDisplay(openTicketRequestDTO.getFlow().getOriginChannel() == "portalB2B" ? "1000" : "10000")
                        .smartTokenIntegrated("")
                        .callerId("234d3bab1b594510434eed7fe54bcb80") // TODO USUARIO DE INTEGRACAO
                        .scrVendorTicket(openTicketRequestDTO.getProtocol())
                        .telephone(openTicketRequestDTO.getCustomer().getAdditionalContact().getContactPhone())
                        .category(openTicketRequestDTO.getCategory())
                        .subCategory(openTicketRequestDTO.getSubCategory())
                        .businessService("ec5e8d7e87986d905e1b33b90cbb3566")
                        .openedBy(openTicketRequestDTO.getOrigin())
                        .customerType(openTicketRequestDTO.getCustomerType())
                        .serviceOffering("")
                        .failureDetail("")
                        .description(openTicketRequestDTO.getDescription())
                        .cpfCnpj(openTicketRequestDTO.getCustomer().getDocNumber())
                        .build();

        return SubmitProducerRequestDTO
                .builder()
                .variables(variables)
                .build();
    }

    public OpenTicketResponseDTO buildSubmitProducerVivoNowResponse(SubmitProducerResponseDTO submitProducerResponseDTO) {
        return OpenTicketResponseDTO
                .builder()
                .sysId(submitProducerResponseDTO != null &&
                        submitProducerResponseDTO.getResult() != null &&
                        submitProducerResponseDTO.getResult().getSysId() != null ?
                        submitProducerResponseDTO.getResult().getSysId() : "")
                .build();
    }

    public UpdateTicketResponseDTO buildUpdateTicketResponse(UpdateIncidentResponseDTO updateIncidentResponseDTO) {
        return UpdateTicketResponseDTO
                .builder()
                .technicalRequestNumber(updateIncidentResponseDTO != null &&
                        updateIncidentResponseDTO.getResultResponseDTO() != null ?
                        updateIncidentResponseDTO.getResultResponseDTO().getNumber() : "")
                .build();
    }

    public UpdateIncidentRequestDTO buildUpdateIncidentRequest(OpenTicketRequestDTO openTicketRequestDTO) {
        return UpdateIncidentRequestDTO
                .builder()
                .scrVendorTicket(openTicketRequestDTO.getProtocol())
                .workNotes(openTicketRequestDTO.getCaseContactType())
                .description(openTicketRequestDTO.getDescription())
                .comments(openTicketRequestDTO.getComments())
                .build();
    }

    public UpdateIncidentRequestDTO buildUpdateIncidentRequest(UpdateTicketRequestDTO updateTicketRequestDTO) {
        return UpdateIncidentRequestDTO
                .builder()
                .scrVendorTicket(updateTicketRequestDTO.getProtocol())
                .workNotes(updateTicketRequestDTO.getCaseContactType())
                .description(updateTicketRequestDTO.getDescription())
                .build();
    }

    public AttachmentFileTicketResponseDTO buildAttachmentFileTicketResponse(VivoNowAttachmentResponseDTO vivoNowAttachmentResponseDTO){
        return AttachmentFileTicketResponseDTO
                .builder()
                .technicalRequestNumber(vivoNowAttachmentResponseDTO != null &&
                        vivoNowAttachmentResponseDTO.getResult() != null? vivoNowAttachmentResponseDTO.getResult().getSys_id() : "")
                .build();
    }
}
