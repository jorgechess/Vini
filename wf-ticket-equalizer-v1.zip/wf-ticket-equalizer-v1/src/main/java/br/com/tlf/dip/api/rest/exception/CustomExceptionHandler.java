package br.com.tlf.dip.api.rest.exception;

import java.util.stream.Collectors;

import org.camunda.bpm.engine.ProcessEngineException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import br.com.tlf.dip.api.rest.exception.dto.CustomError;
import br.com.tlf.dip.api.rest.exception.dto.DataIntegrityException;
import br.com.tlf.dip.api.rest.exception.dto.ErrorDetail;
import br.com.tlf.dip.api.rest.exception.dto.FileException;
import br.com.tlf.dip.api.rest.exception.dto.ObjectNotFoundException;
import br.com.tlf.dip.api.rest.exception.dto.RequestFieldsValidationException;
import br.com.tlf.dip.api.rest.exception.dto.InvalidRequestSFAException;
import br.com.tlf.dip.shared.util.DateUtil;
import jakarta.servlet.http.HttpServletRequest;

/**
 * @author A0096617
 */
@ControllerAdvice
public class CustomExceptionHandler {

	@ExceptionHandler(ObjectNotFoundException.class)
	public ResponseEntity<CustomError> objectNotFound(ObjectNotFoundException e, HttpServletRequest request) {		
		var error = CustomError
				.builder()
				.errorCode(HttpStatus.NOT_FOUND.value())
				.message(e.getMessage())
				.details(request.getRequestURI() + " - " + e.getMessage())
				.timestamp(new DateUtil().getTimestamp())
				.traceId(request.getRequestId())
				.build();		
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(error);		
	}

	@ExceptionHandler(DataIntegrityException.class)
	public ResponseEntity<CustomError> dataIntegrity(DataIntegrityException e, HttpServletRequest request) {		
		var error = CustomError
				.builder()
				.errorCode(HttpStatus.BAD_REQUEST.value())
				.message(e.getMessage())
				.details(request.getRequestURI() + " - " + e.getMessage())
				.timestamp(new DateUtil().getTimestamp())
				.traceId(request.getRequestId())
				.build();		
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);		
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<CustomError> validation(MethodArgumentNotValidException e, HttpServletRequest request) {
		var error = CustomError
				.builder()
				.errorCode(HttpStatus.UNPROCESSABLE_ENTITY.value())
				.message(e.getMessage())
				.details(request.getRequestURI() + " - " + e.getMessage())
				.timestamp(new DateUtil().getTimestamp())
				.traceId(request.getRequestId())
				.errors(e.getBindingResult()
						.getFieldErrors()
						.stream()
						.map(obj -> 
							new ErrorDetail(
								HttpStatus.UNPROCESSABLE_ENTITY.value(),
								obj.getField(), 
								obj.getDefaultMessage()))
						.collect(Collectors.toList()))
				.build();
		return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body(error);		
	}

	@ExceptionHandler(FileException.class)
	public ResponseEntity<CustomError> file(FileException e, HttpServletRequest request) {		
		var error = CustomError
				.builder()
				.errorCode(HttpStatus.BAD_REQUEST.value())
				.message(e.getMessage())
				.details(request.getRequestURI() + " - " + e.getMessage())
				.timestamp(new DateUtil().getTimestamp())
				.traceId(request.getRequestId())
				.build();
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);		
	}

	@ExceptionHandler(MissingRequestHeaderException.class)
	public ResponseEntity<CustomError> missingRequest(MissingRequestHeaderException e, HttpServletRequest request) {		
		var error = CustomError
				.builder()
				.errorCode(HttpStatus.BAD_REQUEST.value())
				.message(e.getMessage())
				.details(request.getRequestURI() + " - " + e.getMessage())
				.timestamp(new DateUtil().getTimestamp())
				.traceId(request.getRequestId())
				.build();
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);		
	}

	@ExceptionHandler(ProcessEngineException.class)
	public ResponseEntity<CustomError> processEngine(ProcessEngineException e, HttpServletRequest request) {		
		var error = CustomError
				.builder()
				.errorCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
				.message(e.getMessage())
				.details(request.getRequestURI() + " - " + e.getMessage())
				.timestamp(new DateUtil().getTimestamp())
				.traceId(request.getRequestId())
				.build();
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);		
	}

	@ExceptionHandler(InternalError.class)
	public ResponseEntity<CustomError> internalError(InternalError e, HttpServletRequest request) {		
		var error = CustomError
				.builder()
				.errorCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
				.message(e.getMessage())
				.details(request.getRequestURI() + " - " + e.getMessage())
				.timestamp(new DateUtil().getTimestamp())
				.traceId(request.getRequestId())
				.build();
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);		
	}
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<CustomError> genericException(Exception e, HttpServletRequest request) {		
		var error = CustomError
				.builder()
				.errorCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
				.message(e.getMessage())
				.details(request.getRequestURI() + " - " + e.getMessage())
				.timestamp(new DateUtil().getTimestamp())
				.traceId(request.getRequestId())
				.build();
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(error);		
	}

	@ExceptionHandler(RequestFieldsValidationException.class)
	public ResponseEntity<CustomError> filedsValidation(Exception e, HttpServletRequest request) {		
		var error = CustomError
				.builder()
				.errorCode(HttpStatus.BAD_REQUEST.value())
				.message(e.getMessage())
				.details(request.getRequestURI() + " - " + e.getMessage())
				.timestamp(new DateUtil().getTimestamp())
				.traceId(request.getRequestId())
				.build();
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);		
	}
	
	@ExceptionHandler(InvalidRequestSFAException.class)
	public ResponseEntity<CustomError> requestSFA(Exception e, HttpServletRequest request) {		
		var error = CustomError
				.builder()
				.errorCode(HttpStatus.BAD_REQUEST.value())
				.message(e.getMessage())
				.details(request.getRequestURI() + " - " + e.getMessage())
				.timestamp(new DateUtil().getTimestamp())
				.traceId(request.getRequestId())
				.build();
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);		
	}

}
