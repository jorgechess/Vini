package br.com.tlf.dip.infrasctructure.rest.vivonow.feign.archive.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class VivoNowAttachmentResponseDTO {

    public AttachmentResultDTO result;
}
