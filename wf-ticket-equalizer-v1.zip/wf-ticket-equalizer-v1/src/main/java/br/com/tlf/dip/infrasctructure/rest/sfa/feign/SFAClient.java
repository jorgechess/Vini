package br.com.tlf.dip.infrasctructure.rest.sfa.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import br.com.tlf.dip.infrasctructure.rest.sfa.feign.dto.RequestSFADTO;
import br.com.tlf.dip.infrasctructure.rest.sfa.feign.dto.ResponseSFADTO;

@FeignClient(name = "SFA", url = "${api-sfa.url}")
public interface SFAClient {

	@PostMapping("/v58.0/composite")
	ResponseSFADTO openSFA(
			@RequestBody RequestSFADTO requestOpen,
			@RequestHeader(name = "Authorization") String token,
			@RequestHeader (name = "iss") String iss);

	@PostMapping("/v58.0/composite")
	ResponseSFADTO updateSFA(
			@RequestBody RequestSFADTO requestUpdate,
			@RequestHeader(name = "Authorization") String token,
			@RequestHeader (name = "iss") String iss);

}
