package br.com.tlf.dip.core.application.mapper;

import br.com.tlf.dip.core.domain.vo.Constants;
import br.com.tlf.dip.core.port.in.dto.BodyRequestDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketRequestDTO;
import br.com.tlf.dip.infrasctructure.rest.sfa.feign.dto.CompositeRequestDTO;

public class BuildSFA {

	public static CompositeRequestDTO buildCompositeRequest(String url, String referenceId) {

		var composite = new CompositeRequestDTO();
		composite.setMethod("GET");
		composite.setReferenceId(referenceId);
		composite.setUrl(url);

		return composite;
	}

	public static CompositeRequestDTO buildNewCaseRef(OpenTicketRequestDTO request) {

		var newCaseRef = new CompositeRequestDTO();
		var body = new BodyRequestDTO();

		body.setHasProtocolC("true");
		body.setAccountId("@{AccountRef.records[0].Id}");
		body.setTechnicalRequestNumberC(request.getTechnicalRequestNumber());
		body.setTechnicalProtocolNumberC(request.getTechnicalRequestProtocol());
		body.setRecordTypeId("@{RecTypeCaseRef.records[0].Id}");
		body.setType(request.getCategory());
		body.setSubcategoryC(request.getSubCategory());
		body.setOwnerId("@{NameOwnerRef.records[0].Id}");
		body.setProductC(request.getProductCatalog());
		body.setOrigin(request.getOrigin());
		body.setDescription(request.getDescription());
		body.setReasonC(request.getReason());
		body.setSubReasonC(request.getSubReason());
		body.setContactId("@{ContactRef.records[0].Id}");
		body.setStatus("Em Tratativa");

		newCaseRef.setMethod("POST");
		newCaseRef.setReferenceId("NewCaseRef");
		newCaseRef.setUrl(Constants.URL_COMPOSITE_REQUEST_NEW_CASE_REF);
		newCaseRef.setBody(body);

		return newCaseRef;
	}

	public static CompositeRequestDTO buildProtocolRef(OpenTicketRequestDTO request) {

		var protocolRef = new CompositeRequestDTO();
		var body = new BodyRequestDTO();

		body.setRecordTypeId("@{RecTypeProtocolRef.records[0].Id}");
		body.setCasoC("@{NewCaseRef.id}");
		body.setOrigemProtocoloC("VivoNet");
		body.setName(Long.parseLong(request.getProtocol()));

		protocolRef.setMethod("POST");
		protocolRef.setReferenceId("ProtocolRef");
		protocolRef.setUrl(Constants.URL_COMPOSITE_REQUEST_PROTOCOL_REF);
		protocolRef.setBody(body);

		return protocolRef;
	}

	public static CompositeRequestDTO buildCommentRef(OpenTicketRequestDTO request) {

		var commentRef = new CompositeRequestDTO();
		var body = new BodyRequestDTO();

		body.setParentId("@{CaseProtocolRef.records[0].Id}");
		body.setCommentBody(request.getCommentsPrivate());

		commentRef.setMethod("POST");
		commentRef.setReferenceId("CommentRef");
		commentRef.setUrl(Constants.URL_COMPOSITE_REQUEST_COMMENT_REF);
		commentRef.setBody(body);

		return commentRef;
	}

	public static CompositeRequestDTO buildCommentRef(UpdateTicketRequestDTO request) {

		var commentRef = new CompositeRequestDTO();
		var body = new BodyRequestDTO();

		body.setParentId("@{NewCaseRef.id}");
		body.setCommentBody(request.getCommentsPrivate());

		commentRef.setMethod("POST");
		commentRef.setReferenceId("CommentRef");
		commentRef.setUrl(Constants.URL_COMPOSITE_REQUEST_COMMENT_REF);
		commentRef.setBody(body);

		return commentRef;
	}

	public static CompositeRequestDTO buildCaseRef(UpdateTicketRequestDTO request) {

		var commentRef = new CompositeRequestDTO();
		var body = new BodyRequestDTO();

		body.setStatus(request.getStatus());
		body.setSolutionC(request.getSolutionCode());
		body.setSolutionDetailC(request.getSolutionDetail());
		body.setTechnicalProtocolNumberC(request.getTechnicalRequestProtocol());
		body.setTechnicalRequestNumberC(request.getTechnicalRequestNumber());
		body.setOwnerId("@{NameOwnerRef.records[0].Id}");

		commentRef.setMethod("PATCH");
		commentRef.setReferenceId("CaseRef");
		commentRef.setUrl(Constants.URL_COMPOSITE_REQUEST_CASE_REF);
		commentRef.setBody(body);

		return commentRef;
	}

}
