package br.com.tlf.dip.core.port.in;

import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketResponseDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketResponseDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketResponseDTO;

public interface ProcessService {

	OpenTicketResponseDTO start(String authorization, OpenTicketRequestDTO openRequestDTO);

	UpdateTicketResponseDTO start(String authorization, UpdateTicketRequestDTO updateRequestDTO);

	AttachmentFileTicketResponseDTO start(String authorization, AttachmentFileTicketRequestDTO attFileTicketRequestDTO);	

}
