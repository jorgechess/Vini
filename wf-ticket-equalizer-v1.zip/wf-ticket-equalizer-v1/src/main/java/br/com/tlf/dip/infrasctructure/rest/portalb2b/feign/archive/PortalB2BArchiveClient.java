package br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.archive;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.archive.dto.AttachFilePortalB2BRequestDTO;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.archive.dto.AttachFilePortalB2BResponseDTO;

@FeignClient(name = "portalB2BArchive", url = "${portalB2BArchive.url}")
public interface PortalB2BArchiveClient {

    @PostMapping("/api/og/opengateway/{vivonet}/attach")
    AttachFilePortalB2BResponseDTO attachFile(
    		@PathVariable("vivonet") String protocol,
            @RequestHeader("Authorization") String authorization,
            @RequestBody AttachFilePortalB2BRequestDTO attachFilePortalB2BRequestDTO);

}
