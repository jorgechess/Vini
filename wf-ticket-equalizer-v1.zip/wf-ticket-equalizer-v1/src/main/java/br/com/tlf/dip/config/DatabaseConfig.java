package br.com.tlf.dip.config;

import java.io.IOException;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import br.com.tlf.dip.properties.DatabaseProperties;
import br.com.tlf.dip.shared.util.SecretUtils;

/**
 * @author Arquitetura Corporativa
 */
@Configuration
public class DatabaseConfig {

	private DatabaseProperties databaseProperties;

	public DatabaseConfig(DatabaseProperties databaseProperties) {
		this.databaseProperties = databaseProperties;
	}

	@Bean
	public DataSource dataSource() throws IOException {
		HikariConfig hikariConfig = new HikariConfig();
		hikariConfig.setDriverClassName(databaseProperties.getDriverClassName());
		hikariConfig.setJdbcUrl(databaseProperties.getUrl());
		hikariConfig.setUsername(SecretUtils.extractSecretValue(databaseProperties.getUsername()));
		hikariConfig.setPassword(SecretUtils.extractSecretValue(databaseProperties.getPassword()));
		hikariConfig.setPoolName(databaseProperties.getPoolName());
		hikariConfig.setMinimumIdle(databaseProperties.getMinPoolSize());
		hikariConfig.setMaximumPoolSize(databaseProperties.getMaxPoolSize());
		hikariConfig.setMaxLifetime(databaseProperties.getMaxLifetime());
		hikariConfig.setValidationTimeout(databaseProperties.getValidationTimeout());
		return new HikariDataSource(hikariConfig);
	}

}