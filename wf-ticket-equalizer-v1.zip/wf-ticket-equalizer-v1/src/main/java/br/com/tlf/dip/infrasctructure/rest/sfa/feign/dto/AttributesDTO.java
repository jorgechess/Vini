package br.com.tlf.dip.infrasctructure.rest.sfa.feign.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AttributesDTO {
	
	private String type;
	private String url;

}
