package br.com.tlf.dip.core.application.service;

import br.com.tlf.dip.core.application.mapper.VivoNowMapper;
import br.com.tlf.dip.core.domain.vo.Constants;
import br.com.tlf.dip.core.port.in.VivoNowService;
import br.com.tlf.dip.core.port.in.dto.OpenTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketResponseDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketResponseDTO;
import br.com.tlf.dip.core.port.out.OamSvcPortOut;
import br.com.tlf.dip.core.port.out.VivoNowPortOut;
import br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external.dto.IncidentDTO;
import br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external.dto.ResultDTO;
import br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external.dto.ResultIncidentDTO;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@Service
@Slf4j
@AllArgsConstructor
@NoArgsConstructor
public class VivoNowServiceImpl implements VivoNowService {

    @Autowired
    private VivoNowPortOut vivoNowPortOut;

    @Autowired
    private OamSvcPortOut oamSvcAdapterOut;

    @Autowired
    private VivoNowMapper vivoNowMapper;

    @Override
    public OpenTicketResponseDTO createCaseVivoNow(String authorization, OpenTicketRequestDTO openTicketRequestDTO) {

        log.info("Realizando chamada de serviço da operação createCase - VivoNow {} ", openTicketRequestDTO.getProtocol());

        var queryStringGetAll = "service.nameSTARTSWITH%s^offer.nameSTARTSWITH%s^failureSTARTSWITH%s";

        var token = "Bearer " + oamSvcAdapterOut.getToken().getAccessToken();

        var sysParmQuery = String.format(queryStringGetAll,
                        encodeValue(openTicketRequestDTO.getProductCatalog()),
                        encodeValue(openTicketRequestDTO.getServiceOffering()),
                        encodeValue(openTicketRequestDTO.getDetail()));

        log.info("sysParmQuery - {}", sysParmQuery);
        log.info("Realizando chamada de serviço da operação getAll - VivoNow {} ", openTicketRequestDTO.getProtocol());

        var getAllResultList = vivoNowPortOut.getAll(token,
                sysParmQuery,
                Constants.CONS_STRING_SYS_PARAM_FIELDS,
                Constants.CONS_STRING_SYS_PARAM_LIMIT,
                Constants.CONS_STRING_SYS_PARAM_DISPLAY_VALUE);

        for (ResultDTO result : getAllResultList.getResult()) {
            openTicketRequestDTO.setProductCatalog(result.getOffer().getValue());
            openTicketRequestDTO.setServiceOffering(result.getService().getValue());
            openTicketRequestDTO.setDetail(result.getFailure().getValue());
        }

        var createCaseRequest = vivoNowMapper.buildSubmitProducerVivoNowRequest(openTicketRequestDTO);
        var createCaseResponse = vivoNowPortOut.submitProducer(token, createCaseRequest);

        var updateIncidentRequest = vivoNowMapper.buildUpdateIncidentRequest(openTicketRequestDTO);

        var updateCaseResponse = vivoNowPortOut.updateIncident(token, createCaseResponse.getResult().getSysId(), updateIncidentRequest);

        return new VivoNowMapper().buildSubmitProducerVivoNowResponse(createCaseResponse);
    }

    @Override
    public UpdateTicketResponseDTO updateCaseVivoNow(String authorization, UpdateTicketRequestDTO updateTicketRequestDTO) {

        log.info("Realizando chamada de serviço da operação updateCase - VivoNow {} ", updateTicketRequestDTO.getProtocol());
        var token = "Bearer " + oamSvcAdapterOut.getToken().getAccessToken();

        log.info("Realizando chamada de serviço da operação GET_SYS - VivoNow {} ", updateTicketRequestDTO.getProtocol());
        var sysParmQuery = "scr_vendor_ticket" + updateTicketRequestDTO.getProtocol();
        var sysParmFields = "number,state,sys_id";
        var sysParmLimit = "1";
        var sysId = "";

        ResultIncidentDTO getSysResponse = vivoNowPortOut.getIncident(token, sysParmQuery, sysParmFields, sysParmLimit, Constants.CONS_STRING_SYS_PARAM_DISPLAY_VALUE);

        if (getSysResponse != null) {
            for (IncidentDTO result : getSysResponse.getResult()) {
                sysId = result.getSysId().getValue();
            }
        }

        var updateIncidentRequest = vivoNowMapper.buildUpdateIncidentRequest(updateTicketRequestDTO);

        var updateIncidentResponse = vivoNowPortOut.updateIncident(token, sysId, updateIncidentRequest);


        return new VivoNowMapper().buildUpdateTicketResponse(updateIncidentResponse);
    }

    private String encodeValue(String value) {
        try {
            return URLEncoder.encode(value, StandardCharsets.UTF_8.toString())
                    .replace("+", " ")//Replace encoded space
                    .replace("%25", "%") //Correct any double encoding
                    .replace("%SE", "^") //Correct ^ encoding
                    .replace("%22", "\""); //Correct "encoding
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("Error encoding value: " + value, e);
        }
    }
}
