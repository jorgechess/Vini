package br.com.tlf.dip.core.application.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tlf.dip.api.rest.exception.dto.InvalidRequestSFAException;
import br.com.tlf.dip.core.application.mapper.BuildSFA;
import br.com.tlf.dip.core.domain.vo.Constants;
import br.com.tlf.dip.core.port.in.SFAService;
import br.com.tlf.dip.core.port.in.dto.OpenTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketResponseDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketResponseDTO;
import br.com.tlf.dip.core.port.out.OamSvcPortOut;
import br.com.tlf.dip.core.port.out.SFAPortOut;
import br.com.tlf.dip.infrasctructure.rest.sfa.feign.dto.CompositeRequestDTO;
import br.com.tlf.dip.infrasctructure.rest.sfa.feign.dto.RequestSFADTO;
import br.com.tlf.dip.infrasctructure.rest.sfa.feign.dto.ResponseSFADTO;
import br.com.tlf.dip.shared.util.StringUtils;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class SFAServiceImpl implements SFAService {
	
	@Autowired
	private SFAPortOut sfaPortOut;
	
	@Autowired
	private OamSvcPortOut oamSvcAdapterOut;

	@Override
	public OpenTicketResponseDTO openSFA(Object requestDTO) {

		log.info("----------------------------------");
		log.info("## Iniciando AccessTokenSvc");	
		
		var token = "Bearer " + oamSvcAdapterOut.getToken().getAccessToken();
		
		log.info("AccesToken {} ", token);
		
		//Objetos para request
		var requestOpenDTO = new OpenTicketRequestDTO();
		var requestSFADTO = new RequestSFADTO();
		var compositeRequestDTOList = new ArrayList<CompositeRequestDTO>();

		if (!(requestDTO instanceof OpenTicketRequestDTO))
			throw new RuntimeException("Objeto Invalido");
		
		requestOpenDTO = (OpenTicketRequestDTO) requestDTO;
		
		compositeRequestDTOList.addAll(buildOpenCompositeList(requestOpenDTO));

		requestSFADTO.setAllOrNone("true");
		requestSFADTO.setCompositeRequest(compositeRequestDTOList);
		
		log.info("----------------------------------");
		log.info("Iniciando chamada do SFA - openTicket - SFAServiceImpl");
		var responseSFA = sfaPortOut.openSFA(requestSFADTO, token);
		var responseTicket = new OpenTicketResponseDTO();
		
		isValidRequest(responseSFA);
		
		responseTicket.setCrmId(responseSFA.getCompositeResponse().get(0).getBody().get(0).getId());
		
		return responseTicket;

	}

	@Override
	public UpdateTicketResponseDTO updateSFA(Object requestDTO) {
		
		log.info("----------------------------------");
		log.info("## Iniciando AccessTokenSvc");
		var token = "Bearer " + oamSvcAdapterOut.getToken().getAccessToken();
		
		log.info("AccesToken {} ", token);

		var requestUpdateDTO = new UpdateTicketRequestDTO();
		var requestSFADTO = new RequestSFADTO();
		var compositeRequestDTOList = new ArrayList<CompositeRequestDTO>();

		if (!(requestDTO instanceof UpdateTicketRequestDTO))
			throw new RuntimeException("Objeto Invalido");
			
		requestUpdateDTO = (UpdateTicketRequestDTO) requestDTO;
		
		compositeRequestDTOList.addAll(buildUpdateCompositeList(requestUpdateDTO));
		
		requestSFADTO.setAllOrNone("true");
		requestSFADTO.setCompositeRequest(compositeRequestDTOList);
		
		log.info("----------------------------------");
		log.info("Iniciando chamada do SFA - updateTicket - SFAServiceImpl");
		var responseSFA = sfaPortOut.updateSFA(requestSFADTO, token);
		var responseTicket = new UpdateTicketResponseDTO();
		
		isValidRequest(responseSFA);
		
		responseTicket.setCrmId(responseSFA.getCompositeResponse().get(0).getBody().get(0).getId());
		
		return responseTicket;
	}
	
	

	private List<CompositeRequestDTO> buildOpenCompositeList(OpenTicketRequestDTO request) {
		
		return Arrays.asList(
				BuildSFA.buildCompositeRequest(StringUtils.formatURLString(request, Constants.URL_COMPOSITE_REQUEST_CONTACT_REF_EMAIL, Constants.URL_COMPOSITE_REQUEST_CONTACT_REF_DOC), "ContactRef"),
				BuildSFA.buildCompositeRequest(Constants.URL_COMPOSITE_REQUEST_NAME_OWNER_REF, "NameOwnerRef"),
				BuildSFA.buildCompositeRequest(Constants.URL_COMPOSITE_REQUEST_REC_TYPE_PROTOCOL_REF, "RecTypeProtocolRef"),
				BuildSFA.buildCompositeRequest(Constants.URL_COMPOSITE_REQUEST_REC_TYPE_CASE_REF, "RecTypeCaseRef"),
				BuildSFA.buildCompositeRequest(StringUtils.formatURLString(request, Constants.URL_COMPOSITE_REQUEST_ACCOUNT_REF), "AccountRef"),
				BuildSFA.buildNewCaseRef(request),
				BuildSFA.buildProtocolRef(request),
				BuildSFA.buildCommentRef(request)
				);
	}
	
	private List<CompositeRequestDTO> buildUpdateCompositeList(UpdateTicketRequestDTO request) {
		return Arrays.asList(
				BuildSFA.buildCompositeRequest(StringUtils.formatURLString(request, Constants.URL_COMPOSITE_REQUEST_CASE_PROTOCOL_REF), "CaseProtocolRef"),
				BuildSFA.buildCompositeRequest(Constants.URL_COMPOSITE_REQUEST_NAME_OWNER_REF, "NameOwnerRef"),
				BuildSFA.buildCaseRef(request),
				BuildSFA.buildCommentRef(request)
				);
	}
	
	private void isValidRequest(ResponseSFADTO response) {
		
		if(response != null && response.getCompositeResponse() != null) {
			var hasInvalidRequest = response.getCompositeResponse().stream()
					.anyMatch(composite -> composite.getHttpStatusCode() >= 400);
			
			var msg = response.getCompositeResponse().get(0).getBody().get(0).getMessage();
			
			if(hasInvalidRequest)
				throw new InvalidRequestSFAException(msg);
		} else {
			throw new RuntimeException("Objeto null");
		}
	}
	
	
}
