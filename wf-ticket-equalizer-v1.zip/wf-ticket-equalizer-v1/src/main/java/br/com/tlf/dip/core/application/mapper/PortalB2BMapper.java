package br.com.tlf.dip.core.application.mapper;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketResponseDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketResponseDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketResponseDTO;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.archive.dto.AttachFilePortalB2BRequestDTO;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.archive.dto.AttachFilePortalB2BResponseDTO;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external.dto.CreateCasePortalB2BRequestDTO;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external.dto.CreateCasePortalB2BResponseDTO;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external.dto.EditCasePortalB2BRequestDTO;
import br.com.tlf.dip.infrasctructure.rest.portalb2b.feign.external.dto.EditCasePortalB2BResponseDTO;
import br.com.tlf.dip.shared.util.StateUtil;

@Component
public class PortalB2BMapper {

	public CreateCasePortalB2BRequestDTO buildCreateCasePortalB2BRequest(OpenTicketRequestDTO openTicketRequestDTO) {		
		return CreateCasePortalB2BRequestDTO
				.builder()
				.uProtocoloVivonet(openTicketRequestDTO.getProtocol())
				.number(openTicketRequestDTO.getTechnicalRequestNumber())
				.uNumberSigitm(openTicketRequestDTO.getTechnicalRequestProtocol())
				.cnpj(openTicketRequestDTO.getCustomer().getDocNumber())
				.email(openTicketRequestDTO.getCustomer().getCaseContactEmail())
				.uAdditionalContactEmail(openTicketRequestDTO.getCustomer().getAdditionalContact().getEmail())
				.uAdditionalContactName(openTicketRequestDTO.getCustomer().getAdditionalContact().getContactName())
				.uAdditionalContactPhone(openTicketRequestDTO.getCustomer().getAdditionalContact().getContactPhone())
				.category(openTicketRequestDTO.getCategory())
				.subcategory(openTicketRequestDTO.getSubCategory())
				.businessService(openTicketRequestDTO.getProductCatalog())
				.contactType(openTicketRequestDTO.getCustomerType())
				.serviceOffering(openTicketRequestDTO.getServiceOffering())
				.uBusinessHour(openTicketRequestDTO.getExpectationDate())
				.description(openTicketRequestDTO.getDescription())
				.workNotes(openTicketRequestDTO.getCommentsPrivate())
				.uAccessId(openTicketRequestDTO.getAccessId())
				.uLine(openTicketRequestDTO.getLine())
				.uHostname(openTicketRequestDTO.getEquipment().getHostname())
				.uSerialNumber(openTicketRequestDTO.getEquipment().getSerialNumber())
				.uEndereco(openTicketRequestDTO.getEquipment().getAddress())
				.comments(openTicketRequestDTO.getComments())
				.state("1")
				.build();
	}

	public OpenTicketResponseDTO buildOpenTicketResponse(CreateCasePortalB2BResponseDTO createCasePortalB2BResponseDTO) {		
		return OpenTicketResponseDTO
				.builder()
				.caseIdB2b(createCasePortalB2BResponseDTO != null && createCasePortalB2BResponseDTO.getResult() != null &&
						createCasePortalB2BResponseDTO.getResult().getCaseId() != null ? 
								createCasePortalB2BResponseDTO.getResult().getCaseId() : "")
				.message(createCasePortalB2BResponseDTO != null && createCasePortalB2BResponseDTO.getResult() != null &&
						createCasePortalB2BResponseDTO.getResult().getMessage() != null ? 
								createCasePortalB2BResponseDTO.getResult().getMessage() : "")
				.build();
	}

	public EditCasePortalB2BRequestDTO buildEditCasePortalB2BRequest(UpdateTicketRequestDTO updateTicketRequestDTO) {		
		return EditCasePortalB2BRequestDTO
				.builder()
				.state(new StateUtil().getPortalB2BState(updateTicketRequestDTO.getStatus()))
				.workNotes(updateTicketRequestDTO.getCommentsPrivate())
				.resolutionCode(updateTicketRequestDTO.getSolutionCode())
				.uDataRespostaCertificacao(updateTicketRequestDTO.getExpectationDate())
				.uCertificado(updateTicketRequestDTO.getCertificado())
				.comments(updateTicketRequestDTO.getCommentsPublic())
				.closeNotes(updateTicketRequestDTO.getCommentsPrivate())
				.uPendingReason(updateTicketRequestDTO.getCommentsPrivate())
				.build();
	}

	public UpdateTicketResponseDTO buildUpdateTicketResponse(EditCasePortalB2BResponseDTO editCasePortalB2BResponseDTO) {		
		return UpdateTicketResponseDTO
				.builder()
				.message(editCasePortalB2BResponseDTO != null && editCasePortalB2BResponseDTO.getResult() != null &&
						editCasePortalB2BResponseDTO.getResult().getSuccess() != null ? 
								editCasePortalB2BResponseDTO.getResult().getSuccess() : "")
				.build();
	}

	public AttachFilePortalB2BRequestDTO buildAttachFilePortalB2BRequest(AttachmentFileTicketRequestDTO attachmentFileTicketRequestDTO) {		
		return AttachFilePortalB2BRequestDTO
				.builder()
				.filename(attachmentFileTicketRequestDTO.getFileName())
				.extension(StringUtils.substringAfterLast(attachmentFileTicketRequestDTO.getFileName(), "."))
				.mimetype("application/" + StringUtils.substringAfterLast(attachmentFileTicketRequestDTO.getFileName(), "."))
				.base64(attachmentFileTicketRequestDTO.getFile().get(0))
				.build();
	}

	public AttachmentFileTicketResponseDTO buildAttachmentFileTicketResponse(AttachFilePortalB2BResponseDTO attachFilePortalB2BResponseDTO) {		
		return AttachmentFileTicketResponseDTO
				.builder()
				.message(attachFilePortalB2BResponseDTO != null && attachFilePortalB2BResponseDTO.getResult() != null &&
						attachFilePortalB2BResponseDTO.getResult().getSuccess() != null ? 
								attachFilePortalB2BResponseDTO.getResult().getSuccess() : "")
				.build();
	}

}
