package br.com.tlf.dip.core.port.in.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class UpdateTicketResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String protocol;

	@JsonProperty("technical_request_number")
	private String technicalRequestNumber;

	@JsonProperty("case_id_b2b")
	private String caseIdB2b;

	@JsonProperty("crm_id")
	private String crmId;

	private String status;

	private String message;

}
