package br.com.tlf.dip.core.port.in.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class CustomerDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("doc_number")
	private String docNumber;

	@JsonProperty("case_contact_email")
	private String caseContactEmail;

	@JsonProperty("case_contact_phone")
	private String caseContactPhone;

	@JsonProperty("comments_public")
	private String commentsPublic;

	@JsonProperty("additional_contact")
	private AdditionalContactDTO additionalContact;

}
