package br.com.tlf.dip.infrasctructure.rest.vivonow.feign.archive.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import spinjar.com.fasterxml.jackson.annotation.JsonProperty;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class AttachmentResultDTO {

    @JsonProperty("size_bytes")
    public String size_bytes;
    @JsonProperty("file_name")
    public String file_name;
    @JsonProperty("sys_mod_count")
    public String sys_mod_count;
    @JsonProperty("average_image_color")
    public String average_image_color;
    @JsonProperty("image_width")
    public String image_width;
    @JsonProperty("sys_updated_on")
    public String sys_updated_on;
    @JsonProperty("sys_tags")
    public String sys_tags;
    @JsonProperty("table_name")
    public String table_name;
    @JsonProperty("sys_id")
    public String sys_id;
    @JsonProperty("image_height")
    public String image_height;
    @JsonProperty("sys_updated_by")
    public String sys_updated_by;
    @JsonProperty("download_link")
    public String download_link;
    @JsonProperty("content_type")
    public String content_type;
    @JsonProperty("sys_created_on")
    public String sys_created_on;
    @JsonProperty("size_compressed")
    public String size_compressed;
    @JsonProperty("compressed")
    public String compressed;
    @JsonProperty("state")
    public String state;
    @JsonProperty("table_sys_id")
    public String table_sys_id;
    @JsonProperty("chunk_size_bytes")
    public String chunk_size_bytes;
    @JsonProperty("hash")
    public String hash;
    @JsonProperty("sys_created_by")
    public String sys_created_by;
}
