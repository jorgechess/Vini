package br.com.tlf.dip.core.application.service;

import java.util.HashMap;
import java.util.Map;

import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.ProcessEngines;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tlf.dip.core.domain.vo.Constants;
import br.com.tlf.dip.core.domain.vo.ProcessEnum;
import br.com.tlf.dip.core.port.in.ProcessService;
import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketResponseDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketResponseDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketResponseDTO;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

/**
 * @author A0096617
 */
@Slf4j
@Service
@AllArgsConstructor
@NoArgsConstructor
public class ProcessServiceImpl implements ProcessService {


	Map<String, Object> variables;

	@Autowired	
	ProcessEngine processEngine;

	@Autowired
	RuntimeService runtimeService;

	ProcessInstance processInstance;

	@Override
	public OpenTicketResponseDTO start(String authorization, OpenTicketRequestDTO openRequestDTO) {
		log.info("Iniciando TicketEqualizer - openTicket");

		variables = new HashMap<>();
		variables.put(ProcessEnum.WF_VAR_CHAMADO_TYPE.getValue(),  openRequestDTO.getFlow().getType());
		variables.put(ProcessEnum.WF_VAR_ORIGIN_CHANNEL.getValue(),  openRequestDTO.getFlow().getOriginChannel());	
		variables.put(ProcessEnum.WF_VAR_PRODUCT.getValue(),  openRequestDTO.getFlow().getProduct());	
		variables.put(ProcessEnum.WF_VAR_REQUEST_DTO.getValue(),  openRequestDTO);
		variables.put(ProcessEnum.WF_VAR_PROTOCOL.getValue(), openRequestDTO.getProtocol());

		processEngine = ProcessEngines.getDefaultProcessEngine();
		runtimeService = processEngine.getRuntimeService();

		processInstance = runtimeService.startProcessInstanceByKey(
			ProcessEnum.WF_NAME_TICKET_EQUALIZER.getValue(), 
				openRequestDTO.getProtocol(), variables);

		log.info(Constants.CONS_STRING_BUSINESS_KEY + " {} ", 
				processInstance.getBusinessKey());
		log.info(Constants.CONS_STRING_PROCESS_INSTANCE_ID + " {} ",  
				processInstance.getProcessInstanceId());
		log.info("TicketEqualizer - openTicket: " + 
				Constants.CONS_STRING_PROCESS_INSTANCE_ID + "#" + 
					processInstance.getProcessInstanceId());

		return OpenTicketResponseDTO.builder()
				.protocol(processInstance.getBusinessKey())
				.message(Constants.CONS_STRING_PROCESS_INSTANCE_ID + "#" + processInstance.getProcessInstanceId())
				.status(Constants.CONS_STRING_RESPONSE_STATUS_SUCCESS)
				.build();

	}

	@Override
	public UpdateTicketResponseDTO start(String authorization, UpdateTicketRequestDTO updateRequestDTO) {
		log.info("Iniciando TicketEqualizer - updateTicket");

		variables = new HashMap<>();
		variables.put(ProcessEnum.WF_VAR_CHAMADO_TYPE.getValue(),  updateRequestDTO.getFlow().getType());
		variables.put(ProcessEnum.WF_VAR_ORIGIN_CHANNEL.getValue(),  updateRequestDTO.getFlow().getOriginChannel());	
		variables.put(ProcessEnum.WF_VAR_PRODUCT.getValue(),  updateRequestDTO.getFlow().getProduct());
		variables.put(ProcessEnum.WF_VAR_REQUEST_DTO.getValue(),  updateRequestDTO);	

		processEngine = ProcessEngines.getDefaultProcessEngine();
		runtimeService = processEngine.getRuntimeService();

		processInstance = runtimeService.startProcessInstanceByKey(
			ProcessEnum.WF_NAME_TICKET_EQUALIZER.getValue(), 
				updateRequestDTO.getProtocol(), variables);

		log.info(Constants.CONS_STRING_BUSINESS_KEY + " {} ",  
				processInstance.getBusinessKey());

		log.info(Constants.CONS_STRING_PROCESS_INSTANCE_ID + " {} ",   
				processInstance.getProcessInstanceId());

		log.info("TicketEqualizer - updateTicket: " + 
				Constants.CONS_STRING_PROCESS_INSTANCE_ID + "#" + 
					processInstance.getProcessInstanceId());

		return UpdateTicketResponseDTO.builder()
				.protocol(processInstance.getBusinessKey())
				.message(Constants.CONS_STRING_PROCESS_INSTANCE_ID + "#" + processInstance.getProcessInstanceId())
				.status(Constants.CONS_STRING_RESPONSE_STATUS_SUCCESS)
				.build();

	}

	@Override
	public AttachmentFileTicketResponseDTO start(String authorization, AttachmentFileTicketRequestDTO attFileTicketRequestDTO) {
		log.info("Iniciando TicketEqualizer - attachmentFileTicket");
	
		variables = new HashMap<>();
		variables.put(ProcessEnum.WF_VAR_CHAMADO_TYPE.getValue(),  attFileTicketRequestDTO.getFlow().getType());
		variables.put(ProcessEnum.WF_VAR_ORIGIN_CHANNEL.getValue(),  attFileTicketRequestDTO.getFlow().getOriginChannel());	
		variables.put(ProcessEnum.WF_VAR_PRODUCT.getValue(),  attFileTicketRequestDTO.getFlow().getProduct());
		variables.put(ProcessEnum.WF_VAR_REQUEST_DTO.getValue(),  attFileTicketRequestDTO);
		
		processEngine = ProcessEngines.getDefaultProcessEngine();
		runtimeService = processEngine.getRuntimeService();

		processInstance = runtimeService.startProcessInstanceByKey(
			ProcessEnum.WF_NAME_TICKET_EQUALIZER.getValue(), 
				attFileTicketRequestDTO.getProtocol(), variables);

		log.info(Constants.CONS_STRING_BUSINESS_KEY + " {} ",
				processInstance.getBusinessKey());

		log.info(Constants.CONS_STRING_PROCESS_INSTANCE_ID + " {} ",  
				processInstance.getProcessInstanceId());

		log.info("TicketEqualizer - attachmentFileTicket {} " + 
			Constants.CONS_STRING_PROCESS_INSTANCE_ID + "#" + 
				processInstance.getProcessInstanceId());

		return AttachmentFileTicketResponseDTO.builder()
				.protocol(processInstance.getBusinessKey())
				.message(Constants.CONS_STRING_PROCESS_INSTANCE_ID + "#" + processInstance.getProcessInstanceId())
				.status(Constants.CONS_STRING_RESPONSE_STATUS_SUCCESS)
				.build();
	}

}
