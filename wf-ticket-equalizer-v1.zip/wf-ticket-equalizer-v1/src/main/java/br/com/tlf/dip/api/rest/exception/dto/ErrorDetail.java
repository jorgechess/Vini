package br.com.tlf.dip.api.rest.exception.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class ErrorDetail {

	@JsonProperty("_code")
	private Integer code;

	@JsonProperty("_field")
	private String field;

	@JsonProperty("_message")
	private String message;

}
