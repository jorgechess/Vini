package br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import spinjar.com.fasterxml.jackson.annotation.JsonProperty;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class UpdateIncidentRequestDTO {

    @JsonProperty("description")
    public String description;
    @JsonProperty("scr_vendor_ticket")
    public String scrVendorTicket;
    @JsonProperty("correlation_id")
    public String correlationId;
    @JsonProperty("correlation_display")
    public String correlationDisplay;
    @JsonProperty("work_notes")
    public String workNotes;
    @JsonProperty("comments")
    public String comments;
}
