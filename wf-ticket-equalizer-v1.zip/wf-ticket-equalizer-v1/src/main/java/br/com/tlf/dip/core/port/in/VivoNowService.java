package br.com.tlf.dip.core.port.in;

import br.com.tlf.dip.core.port.in.dto.OpenTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketResponseDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketResponseDTO;

public interface VivoNowService {

    OpenTicketResponseDTO createCaseVivoNow(String authorization,
                                            OpenTicketRequestDTO openTicketRequestDTO);

    UpdateTicketResponseDTO updateCaseVivoNow(String authorization,
                                              UpdateTicketRequestDTO updateTicketRequestDTO);
}
