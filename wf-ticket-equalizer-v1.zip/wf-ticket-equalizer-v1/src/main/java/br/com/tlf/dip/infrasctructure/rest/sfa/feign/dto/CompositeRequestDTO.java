package br.com.tlf.dip.infrasctructure.rest.sfa.feign.dto;

import br.com.tlf.dip.core.port.in.dto.BodyRequestDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompositeRequestDTO {
	
	private String method;
	private String referenceId;
	private String url;
	private BodyRequestDTO body;

}
