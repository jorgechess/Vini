package br.com.tlf.dip.core.port.in.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class UpdateTicketRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private FlowDTO flow;

	private String protocol;

	@JsonProperty("technical_request_number")
	private String technicalRequestNumber;
	
	@JsonProperty("technical_request_protocol")
	private String technicalRequestProtocol;

	@JsonProperty("solution_code")
	private String solutionCode;

	@JsonProperty("solution_detail")
	private String solutionDetail;

	@JsonProperty("comments_private")
	private String commentsPrivate;

	@JsonProperty("comments_public")
	private String commentsPublic;

	@JsonProperty("case_contact_type")
	private String caseContactType;

	@JsonProperty("expectation_date")
	private String expectationDate;

	private String description;

	private String status;
	
	private String certificado;

}
