package br.com.tlf.dip.infrasctructure.rest.errorrecovery;

import br.com.tlf.dip.core.port.out.ErrorRecoveryPortOut;
import br.com.tlf.dip.infrasctructure.rest.errorrecovery.feign.ErrorRecoveryClient;
import br.com.tlf.dip.infrasctructure.rest.errorrecovery.feign.dto.ErrorRecoveryStartDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ErrorRecoveryPortOutImpl implements ErrorRecoveryPortOut{

    @Autowired
    ErrorRecoveryClient errorRecoveryClient;

    @Override
    public String start(String start, ErrorRecoveryStartDTO errorRecoveryStartDTO){
        return errorRecoveryClient.start(errorRecoveryStartDTO, start);
    }
}
