package br.com.tlf.dip.core.application.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.tlf.dip.core.application.mapper.PortalB2BMapper;
import br.com.tlf.dip.core.port.in.PortalB2BExternalService;
import br.com.tlf.dip.core.port.in.dto.OpenTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketResponseDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketResponseDTO;
import br.com.tlf.dip.core.port.out.OamSvcPortOut;
import br.com.tlf.dip.core.port.out.PortalB2BExternalPortOut;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
@NoArgsConstructor
public class PortalB2BExternalServiceImpl implements PortalB2BExternalService {

	@Autowired
	private PortalB2BExternalPortOut portalB2BExternalPortOut;
	
	@Autowired
	private OamSvcPortOut oamSvcAdapterOut;

	@Autowired
	private PortalB2BMapper mapper;

	public OpenTicketResponseDTO createCasePortalB2B(String authorization, 
			OpenTicketRequestDTO openTicketRequestDTO) {

		log.info("Realizando chamada de serviço da operação createCase - PortalB2B {} ", openTicketRequestDTO.getProtocol());
		
		var token = "Bearer " + oamSvcAdapterOut.getToken().getAccessToken();

		var createCaseRequest = mapper.buildCreateCasePortalB2BRequest(openTicketRequestDTO);
		var createCaseResponse = portalB2BExternalPortOut.createCase(token, createCaseRequest);

		log.info("Chamada de serviço da operação createCase finalizada - PortalB2B {} ", createCaseResponse);

		return new PortalB2BMapper().buildOpenTicketResponse(createCaseResponse);

	}

	public UpdateTicketResponseDTO editCasePortalB2B(String authorization, 
			UpdateTicketRequestDTO updateTicketRequestDTO) {

		log.info("Realizando chamada de serviço da operação editCase - PortalB2B {} ", updateTicketRequestDTO.getProtocol());
		
		var token = "Bearer " + oamSvcAdapterOut.getToken().getAccessToken();

		var editCaseRequest = mapper.buildEditCasePortalB2BRequest(updateTicketRequestDTO);
		var editCaseResponse = portalB2BExternalPortOut.editCase(updateTicketRequestDTO.getProtocol(),
				token, editCaseRequest);

		log.info("Chamada de serviço da operação editCase finalizada - PortalB2B {} ", editCaseResponse);
		return new PortalB2BMapper().buildUpdateTicketResponse(editCaseResponse);
		
	}

}
