package br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external;

import br.com.tlf.dip.infrasctructure.rest.vivonow.feign.external.dto.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "vivoNow", url = "${api-vivonow.url}")
public interface VivoNowClient {

    @PostMapping("sn_sc/servicecatalog/items/3196d3371bb4f91076e68590f54bcbd1/submit_producer")
    SubmitProducerResponseDTO submitProducer(
            @RequestHeader("Authorization") String authorization,
            @RequestBody SubmitProducerRequestDTO submitProducerRequestDTO);

    @GetMapping("now/table/x_tev_sn_developme_failure_detail")
    GetAllResponseDTO getAll(
            @RequestHeader("Authorization") String authorization,
            @RequestParam("sysparm_query") String sysParamQuery,
            @RequestParam("sysparm_fields") String sysParmFields,
            @RequestParam("sysparm_limit") String sysParmLimit,
            @RequestParam("sysparm_display_value") String sysParmDisplayValue);

    @PatchMapping("now/table/incident/{id}")
    UpdateIncidentResponseDTO updateIncident(
            @RequestHeader("Authorization") String authorization,
            @PathVariable("id") String incidentId,
            @RequestBody UpdateIncidentRequestDTO updateIncidentRequestDTO);

    @GetMapping("now/table/incident")
    ResultIncidentDTO getIncident(@RequestHeader("Authorization") String authorization,
                                  @RequestParam("sysparm_query") String sysParamQuery,
                                  @RequestParam("sysparm_fields") String sysParmFields,
                                  @RequestParam("sysparm_limit") String sysParmLimit,
                                  @RequestParam("sysparm_display_value") String sysParmDisplayValue);

}
