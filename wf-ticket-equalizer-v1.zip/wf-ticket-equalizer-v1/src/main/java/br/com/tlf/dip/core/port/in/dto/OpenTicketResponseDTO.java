package br.com.tlf.dip.core.port.in.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@NonNull
public class OpenTicketResponseDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("case_id_b2b")
	private String caseIdB2b;

	@JsonProperty("crm_id")
	private String crmId;

	@JsonProperty("sysId")
	private String sysId;

	private String message;

	private String protocol;

	private String status;	

	@JsonProperty("technical_request_number")
	private String technicalRequestNumber;	

}
