package br.com.tlf.dip.core.port.in.dto;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class AttachmentFileTicketRequestDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private FlowDTO flow;

	@JsonProperty("file_name")
	private String fileName;

	private String title;

	private String protocol;

	private List<String> file;

	@Override
    public String toString() {
        return "AttachmentFileTicketRequestDTO{" +
        		"flow='" + flow +'\'' +
        		", file_name='" + fileName + '\'' +
        		", title='" + title + '\'' +
        		", protocol='" + protocol + '\'' +
        		// Está logando o hash desse atributo pq vem uma String muito grande e impacta na manutenção
                "file='" + file.hashCode() + " (hashcode)" +'\'' +
                '}';
    }

}
