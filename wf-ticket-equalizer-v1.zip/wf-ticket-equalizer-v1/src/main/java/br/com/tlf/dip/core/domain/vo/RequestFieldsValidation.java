package br.com.tlf.dip.core.domain.vo;

import java.util.ArrayList;
import java.util.List;

import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.OpenTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.UpdateTicketRequestDTO;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class RequestFieldsValidation {

	List<String> fileds = new ArrayList<String>();

	/**
	 * Valida os parâmetros de entrada obrigatórios da operação /open
	 * No caso de encontrar algum dos campos mapeados abaixo no JSON de entrada
	 * vai adicionando em uma lista de string para retornar ao consumidor.
	 * @param openTicketRequestDTO
	 * @return List<String>
	 */
	public List<String> validation(OpenTicketRequestDTO openTicketRequestDTO) {	
		
		log.info("Iniciando validação da request - openTicketRequest");

		/*
		 * Valida os campos obrigatórios do obj Flow para todos os fluxos
		 */
		if (openTicketRequestDTO.getFlow() == null) {
			fileds.add("flow");
			return fileds;
		}

		if (openTicketRequestDTO.getFlow().getOriginChannel() == null || 
				openTicketRequestDTO.getFlow().getOriginChannel().isEmpty() || 
					openTicketRequestDTO.getFlow().getOriginChannel().isBlank()) {
			fileds.add("originChannel");		
		}

		if (openTicketRequestDTO.getFlow().getType() == null || 
				openTicketRequestDTO.getFlow().getType().isEmpty() || 
					openTicketRequestDTO.getFlow().getType().isBlank()) {
			fileds.add("type");		
		}

		if (openTicketRequestDTO.getFlow().getProduct() == null || 
				openTicketRequestDTO.getFlow().getProduct().isEmpty() || 
					openTicketRequestDTO.getFlow().getProduct().isBlank()) {
			fileds.add("product");
		}

		/*
		 * Valida se o consumidor está autorizado a consumir o flow
		 */
		if (!getOriginChannel().contains(openTicketRequestDTO.getFlow().getOriginChannel().toUpperCase())) {
			fileds.add("O seguinte consumidor é inválido: " + openTicketRequestDTO.getFlow().getOriginChannel());
		}

		/*
		 * Valida os campos obrigatórios para cada consumidor
		 */

		/*
		 * Todos consumidores diferentes do portalB2B
		 */
		if (openTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("vivoNow") ||
				openTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("SFA")) {
			
			log.info("Iniciando validação dos comsumidores diferentes do portalB2B - openTicketRequest");
			
			if (openTicketRequestDTO.getProtocol() == null || 
					openTicketRequestDTO.getProtocol().isEmpty() || 
						openTicketRequestDTO.getProtocol().isBlank()) {
				fileds.add("protocol");		
			}
			if (openTicketRequestDTO.getTechnicalRequestProtocol() == null || 
					openTicketRequestDTO.getTechnicalRequestProtocol().isEmpty() || 
						openTicketRequestDTO.getTechnicalRequestProtocol().isBlank()) {
				fileds.add("technical_request_protocol");		
			}
			if (openTicketRequestDTO.getTechnicalRequestNumber() == null || 
					openTicketRequestDTO.getTechnicalRequestNumber().isEmpty() || 
						openTicketRequestDTO.getTechnicalRequestNumber().isBlank()) {
				fileds.add("technical_request_number");
			}
			if (openTicketRequestDTO.getCategory() == null ||
					openTicketRequestDTO.getCategory().isEmpty() ||
						openTicketRequestDTO.getCategory().isBlank()) {
				 fileds.add("category");
			}
			if (openTicketRequestDTO.getSubCategory() == null ||
					openTicketRequestDTO.getSubCategory().isEmpty() ||
						openTicketRequestDTO.getSubCategory().isBlank()) {
				 fileds.add("subCategory");
			}
			if (openTicketRequestDTO.getProductCatalog() == null ||
					openTicketRequestDTO.getProductCatalog().isEmpty() ||
						openTicketRequestDTO.getProductCatalog().isBlank()) {
				 fileds.add("product_catalog");
			}
			if (openTicketRequestDTO.getCustomerType() == null ||
					openTicketRequestDTO.getCustomerType().isEmpty() ||
						openTicketRequestDTO.getCustomerType().isBlank()) {
				 fileds.add("customer_type");
			}
			if (openTicketRequestDTO.getServiceOffering() == null ||
					openTicketRequestDTO.getServiceOffering().isEmpty() ||
						openTicketRequestDTO.getServiceOffering().isBlank()) {
				 fileds.add("service_offering");
			}
			if (openTicketRequestDTO.getExpectationDate() == null ||
					openTicketRequestDTO.getExpectationDate().isEmpty() ||
						openTicketRequestDTO.getExpectationDate().isBlank()) {
				 fileds.add("expectation_date");
			}
			if (openTicketRequestDTO.getDescription() == null ||
					openTicketRequestDTO.getDescription().isEmpty() ||
						openTicketRequestDTO.getDescription().isBlank()) {
				 fileds.add("description");
			}
			if (openTicketRequestDTO.getCommentsPrivate() == null ||
					openTicketRequestDTO.getCommentsPrivate().isEmpty() ||
						openTicketRequestDTO.getCommentsPrivate().isBlank()) {
				 fileds.add("comments_private");
			}
			if (openTicketRequestDTO.getAccessId() == null ||
					openTicketRequestDTO.getAccessId().isEmpty() ||
						openTicketRequestDTO.getAccessId().isBlank()) {
				 fileds.add("access_id");
			}
			if (openTicketRequestDTO.getLine() == null ||
					openTicketRequestDTO.getLine().isEmpty() ||
						openTicketRequestDTO.getLine().isBlank()) {
				 fileds.add("line");
			}
			if (openTicketRequestDTO.getComments() == null ||
					openTicketRequestDTO.getComments().isEmpty() ||
						openTicketRequestDTO.getComments().isBlank()) {
				 fileds.add("comments");
			}
				
			/*
			 * Customer
			 */
			if (openTicketRequestDTO.getCustomer() == null) {
				 fileds.add("customer");
				 return fileds;
			}
			if (openTicketRequestDTO.getCustomer().getDocNumber() == null ||
					openTicketRequestDTO.getCustomer().getDocNumber().isEmpty() ||
						openTicketRequestDTO.getCustomer().getDocNumber().isBlank()) {
				 fileds.add("doc_number");
			}
			if (openTicketRequestDTO.getCustomer().getCaseContactEmail() == null ||
					openTicketRequestDTO.getCustomer().getCaseContactEmail().isEmpty() ||
						openTicketRequestDTO.getCustomer().getCaseContactEmail().isBlank()) {
				 fileds.add("case_contact_email");
			}
			
			/*
			 * AdditionalContact
			 */
			if (openTicketRequestDTO.getCustomer().getAdditionalContact() == null) {
				 fileds.add("additional_contact");
				 return fileds;
			}
			if (openTicketRequestDTO.getCustomer().getAdditionalContact().getEmail() == null ||
					openTicketRequestDTO.getCustomer().getAdditionalContact().getEmail().isEmpty() ||
						openTicketRequestDTO.getCustomer().getAdditionalContact().getEmail().isBlank()) {
				 fileds.add("email");
			}
			if (openTicketRequestDTO.getCustomer().getAdditionalContact().getContactName() == null ||
					openTicketRequestDTO.getCustomer().getAdditionalContact().getContactName().isEmpty() ||
						openTicketRequestDTO.getCustomer().getAdditionalContact().getContactName().isBlank()) {
				 fileds.add("contact_name");
			}
			if (openTicketRequestDTO.getCustomer().getAdditionalContact().getContactPhone() == null ||
					openTicketRequestDTO.getCustomer().getAdditionalContact().getContactPhone().isEmpty() ||
						openTicketRequestDTO.getCustomer().getAdditionalContact().getContactPhone().isBlank()) {
				 fileds.add("contact_phone");
			}
			
			/*
			 * Equipment
			 */
			if (openTicketRequestDTO.getEquipment() == null) {
				 fileds.add("equipment");
				 return fileds;
			}
			if (openTicketRequestDTO.getEquipment().getHostname() == null ||
					openTicketRequestDTO.getEquipment().getHostname().isEmpty() ||
						openTicketRequestDTO.getEquipment().getHostname().isBlank()) {
				 fileds.add("hostname");
			}
			if (openTicketRequestDTO.getEquipment().getSerialNumber() == null ||
					openTicketRequestDTO.getEquipment().getSerialNumber().isEmpty() ||
						openTicketRequestDTO.getEquipment().getSerialNumber().isBlank()) {
				 fileds.add("serial_number");
			}
			if (openTicketRequestDTO.getEquipment().getAddress() == null ||
					openTicketRequestDTO.getEquipment().getAddress().isEmpty() ||
						openTicketRequestDTO.getEquipment().getAddress().isBlank()) {
				 fileds.add("address");
			}
			
		}

		/*
		 * Todos consumidores diferentes do vivoNow
		 */
		if (openTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("portalB2B") ||
				openTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("SFA")) {

			log.info("Iniciando validação dos comsumidores diferentes do vivoNow - openTicketRequest");

		}

		/*
		 * Todos consumidores diferentes do SFA
		 */
		if (openTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("portalB2B") ||
				openTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("vivoNow")) {
			
			log.info("Iniciando validação dos comsumidores diferentes do SFA - openTicketRequest");
			
			if (openTicketRequestDTO.getProtocol() == null ||
					openTicketRequestDTO.getProtocol().isEmpty() ||
					openTicketRequestDTO.getProtocol().isBlank()) {
				 fileds.add("protocol");
			}
			
			if (openTicketRequestDTO.getCategory() == null ||
					openTicketRequestDTO.getCategory().isEmpty() ||
					openTicketRequestDTO.getCategory().isBlank()) {
				fileds.add("category");
			}
			
			if (openTicketRequestDTO.getSubCategory() == null ||
					openTicketRequestDTO.getSubCategory().isEmpty() ||
					openTicketRequestDTO.getSubCategory().isBlank()) {
				fileds.add("subCategory");
			}
			
			if (openTicketRequestDTO.getProductCatalog() == null ||
					openTicketRequestDTO.getProductCatalog().isEmpty() ||
					openTicketRequestDTO.getProductCatalog().isBlank()) {
				fileds.add("product_catalog");
			}
			
			if (openTicketRequestDTO.getOrigin() == null ||
					openTicketRequestDTO.getOrigin().isEmpty() ||
					openTicketRequestDTO.getOrigin().isBlank()) {
				fileds.add("origin");
			}
			
			if (openTicketRequestDTO.getDescription() == null ||
					openTicketRequestDTO.getDescription().isEmpty() ||
					openTicketRequestDTO.getDescription().isBlank()) {
				fileds.add("description");
			}
			
			if (openTicketRequestDTO.getReason() == null ||
					openTicketRequestDTO.getReason().isEmpty() ||
					openTicketRequestDTO.getReason().isBlank()) {
				fileds.add("reason");
			}
			
			if (openTicketRequestDTO.getSubReason() == null ||
					openTicketRequestDTO.getSubReason().isEmpty() ||
					openTicketRequestDTO.getSubReason().isBlank()) {
				fileds.add("subReason");
			}
			
			if (openTicketRequestDTO.getCommentsPrivate() == null ||
					openTicketRequestDTO.getCommentsPrivate().isEmpty() ||
					openTicketRequestDTO.getCommentsPrivate().isBlank()) {
				fileds.add("comments_private");
			}
			
			/*
			 * Customer
			 */
			if (openTicketRequestDTO.getCustomer() == null) {
				 fileds.add("customer");
				 return fileds;
			}
			
			if (openTicketRequestDTO.getCustomer().getDocNumber() == null ||
					openTicketRequestDTO.getCustomer().getDocNumber().isEmpty() ||
						openTicketRequestDTO.getCustomer().getDocNumber().isBlank()) {
				 fileds.add("doc_number");
			}
			if (openTicketRequestDTO.getCustomer().getCaseContactEmail() == null ||
					openTicketRequestDTO.getCustomer().getCaseContactEmail().isEmpty() ||
						openTicketRequestDTO.getCustomer().getCaseContactEmail().isBlank()) {
				 fileds.add("case_contact_email");
			}
			
		}

		return fileds;
	}

	/**
	 * Valida os parâmetros de entrada obrigatórios da operação /update
	 * No caso de encontrar algum dos campos mapeados abaixo no JSON de entrada
	 * vai adicionando em uma lista de string para retornar ao consumidor.
	 * @param updateTicketRequestDTO
	 * @return List<String>
	 */
	public List<String> validation(UpdateTicketRequestDTO updateTicketRequestDTO) {
		
		log.info("Iniciando validação da request - updateTicketRequest");
		
		/*
		 * Valida os campos obrigatórios do obj Flow para todos os fluxos
		 */
		if (updateTicketRequestDTO.getFlow() == null) {
			fileds.add("flow");
			return fileds;
		}
		
		if (updateTicketRequestDTO.getFlow().getOriginChannel() == null || 
				updateTicketRequestDTO.getFlow().getOriginChannel().isEmpty() || 
					updateTicketRequestDTO.getFlow().getOriginChannel().isBlank()) {
			fileds.add("originChannel");		
		}
		
		if (updateTicketRequestDTO.getFlow().getType() == null || 
				updateTicketRequestDTO.getFlow().getType().isEmpty() || 
					updateTicketRequestDTO.getFlow().getType().isBlank()) {
			fileds.add("type");		
		}
		
		if (updateTicketRequestDTO.getFlow().getProduct() == null || 
				updateTicketRequestDTO.getFlow().getProduct().isEmpty() || 
					updateTicketRequestDTO.getFlow().getProduct().isBlank()) {
			fileds.add("product");		
		}

		/*
		 * Valida se o consumidor está autorizado a consumir o flow
		 */
		if (!getOriginChannel().contains(updateTicketRequestDTO.getFlow().getOriginChannel().toUpperCase())) {
			fileds.add("O seguinte consumidor é inválido: " + updateTicketRequestDTO.getFlow().getOriginChannel());
		}

		/*
		 * Valida os campos obrigatórios para cada consumidor
		 */

		/*
		 * Todos consumidores diferentes do portalB2B
		 */
		if (updateTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("vivoNow") ||
				updateTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("SFA")) {
			
			log.info("Iniciando validação dos comsumidores diferentes do portalB2B - updateTicketRequest");
			
			if (updateTicketRequestDTO.getProtocol() == null || 
					updateTicketRequestDTO.getProtocol().isEmpty() || 
						updateTicketRequestDTO.getProtocol().isBlank()) {
				fileds.add("protocol");		
			}
			if (updateTicketRequestDTO.getStatus() == null || 
					updateTicketRequestDTO.getStatus().isEmpty() || 
						updateTicketRequestDTO.getStatus().isBlank()) {
				fileds.add("status");		
			}			
			if (updateTicketRequestDTO.getCommentsPrivate() == null || 
					updateTicketRequestDTO.getCommentsPrivate().isEmpty() || 
						updateTicketRequestDTO.getCommentsPrivate().isBlank()) {
				fileds.add("comments_private");		
			}
			if (updateTicketRequestDTO.getSolutionCode() == null || 
					updateTicketRequestDTO.getSolutionCode().isEmpty() || 
						updateTicketRequestDTO.getSolutionCode().isBlank()) {
				fileds.add("solution_code");		
			}
			if (updateTicketRequestDTO.getExpectationDate() == null || 
					updateTicketRequestDTO.getExpectationDate().isEmpty() || 
						updateTicketRequestDTO.getExpectationDate().isBlank()) {
				fileds.add("expectation_date");		
			}
			if (updateTicketRequestDTO.getCertificado() == null || 
					updateTicketRequestDTO.getCertificado().isEmpty() || 
						updateTicketRequestDTO.getCertificado().isBlank()) {
				fileds.add("certificado");		
			}
			if (updateTicketRequestDTO.getCommentsPublic() == null || 
					updateTicketRequestDTO.getCommentsPublic().isEmpty() || 
						updateTicketRequestDTO.getCommentsPublic().isBlank()) {
				fileds.add("comments_public");		
			}
			
		}

		/*
		 * Todos consumidores diferentes do vivoNow
		 */
		if (updateTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("portalB2B") ||
				updateTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("SFA")) {
			
			log.info("Iniciando validação dos comsumidores diferentes do vivoNow - updateTicketRequest");
			
		}

		/*
		 * Todos consumidores diferentes do SFA
		 */
		if (updateTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("portalB2B") ||
				updateTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("vivoNow")) {
			
			log.info("Iniciando validação dos comsumidores diferentes do SFA - updateTicketRequest");
			
			if (updateTicketRequestDTO.getProtocol() == null || 
					updateTicketRequestDTO.getProtocol().isEmpty() || 
						updateTicketRequestDTO.getProtocol().isBlank()) {
				fileds.add("protocol");		
			}
			
			if (updateTicketRequestDTO.getTechnicalRequestNumber() == null || 
					updateTicketRequestDTO.getTechnicalRequestNumber().isEmpty() || 
					updateTicketRequestDTO.getTechnicalRequestNumber().isBlank()) {
				fileds.add("technical_request_number");		
			}
			
			if (updateTicketRequestDTO.getTechnicalRequestProtocol() == null || 
					updateTicketRequestDTO.getTechnicalRequestProtocol().isEmpty() || 
					updateTicketRequestDTO.getTechnicalRequestProtocol().isBlank()) {
				fileds.add("technical_request_protocol");		
			}
			
			if (updateTicketRequestDTO.getStatus() == null || 
					updateTicketRequestDTO.getStatus().isEmpty() || 
					updateTicketRequestDTO.getStatus().isBlank()) {
				fileds.add("status");		
			}
			
			if (updateTicketRequestDTO.getSolutionCode() == null || 
					updateTicketRequestDTO.getSolutionCode().isEmpty() || 
					updateTicketRequestDTO.getSolutionCode().isBlank()) {
				fileds.add("solution_code");		
			}
			
			if (updateTicketRequestDTO.getSolutionDetail() == null || 
					updateTicketRequestDTO.getSolutionDetail().isEmpty() || 
					updateTicketRequestDTO.getSolutionDetail().isBlank()) {
				fileds.add("solution_detail");		
			}
			
			if (updateTicketRequestDTO.getCommentsPrivate() == null || 
					updateTicketRequestDTO.getCommentsPrivate().isEmpty() || 
					updateTicketRequestDTO.getCommentsPrivate().isBlank()) {
				fileds.add("comments_private");		
			}
			
		}
		
		return fileds;		
	}

	/**
	 * Valida os parâmetros de entrada obrigatórios da operação /attachment/file
	 * No caso de encontrar algum dos campos mapeados abaixo no JSON de entrada
	 * vai adicionando em uma lista de string para retornar ao consumidor.
	 * @param attFileTicketRequestDTO
	 * @return List<String>
	 */
	public List<String> validation(AttachmentFileTicketRequestDTO attFileTicketRequestDTO) {
		
		log.info("Iniciando validação da request - attFileTicketRequest");
		
		/*
		 * Valida os campos obrigatórios do obj Flow para todos os fluxos
		 */
		if (attFileTicketRequestDTO.getFlow() == null) {
			fileds.add("flow");
			return fileds;
		}
		
		if (attFileTicketRequestDTO.getFlow().getOriginChannel() == null || 
				attFileTicketRequestDTO.getFlow().getOriginChannel().isEmpty() || 
					attFileTicketRequestDTO.getFlow().getOriginChannel().isBlank()) {
			fileds.add("originChannel");		
		}
		
		if (attFileTicketRequestDTO.getFlow().getType() == null || 
				attFileTicketRequestDTO.getFlow().getType().isEmpty() || 
					attFileTicketRequestDTO.getFlow().getType().isBlank()) {
			fileds.add("type");		
		}
		
		if (attFileTicketRequestDTO.getFlow().getProduct() == null || 
				attFileTicketRequestDTO.getFlow().getProduct().isEmpty() || 
					attFileTicketRequestDTO.getFlow().getProduct().isBlank()) {
			fileds.add("product");
		}

		/*
		 * Valida se o consumidor está autorizado a consumir o flow
		 */
		if (!getOriginChannel().contains(attFileTicketRequestDTO.getFlow().getOriginChannel().toUpperCase())) {
			fileds.add("O seguinte consumidor é inválido: " + attFileTicketRequestDTO.getFlow().getOriginChannel());
		}

		/*
		 * Valida os campos obrigatórios para cada consumidor
		 */

		/*
		 * Todos consumidores diferentes do portalB2B
		 */
		if (attFileTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("vivoNow") ||
				attFileTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("SFA")) {
			
			log.info("Iniciando validação dos comsumidores diferentes do portalB2B - attFileTicketRequest");
			
			if (attFileTicketRequestDTO.getProtocol() == null || 
					attFileTicketRequestDTO.getProtocol().isEmpty() || 
					attFileTicketRequestDTO.getProtocol().isBlank()) {
				fileds.add("protocol");		
			}
			if (attFileTicketRequestDTO.getFileName() == null || 
					attFileTicketRequestDTO.getFileName().isEmpty() || 
					attFileTicketRequestDTO.getFileName().isBlank()) {
				fileds.add("file_name");		
			}
			if (attFileTicketRequestDTO.getFile() == null || 
					attFileTicketRequestDTO.getFile().isEmpty()) {
				fileds.add("file");		
			}
		}

		/*
		 * Todos consumidores diferentes do vivoNow
		 */
		if (attFileTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("portalB2B") ||
				attFileTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("SFA")) {
			
			log.info("Iniciando validação dos comsumidores diferentes do vivoNow - attFileTicketRequest");
			
		}

		/*
		 * Todos consumidores diferentes do SFA
		 */
		if (attFileTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("portalB2B") ||
				attFileTicketRequestDTO.getFlow().getOriginChannel().equalsIgnoreCase("vivoNow")) {
			
			log.info("Iniciando validação dos comsumidores diferentes do SFA - attFileTicketRequest");
			
		}

		return fileds;
	}

	/**
	 * Retorna a lista de todos os consumidores autorizados a consumir o flow
	 * No caso de novo consumidor, incremetar essa lista e a validação
	 * dos campos obrigatórios correspondentes
	 * @return List<String>
	 */
	private List<String> getOriginChannel() {
		List<String> originChannels = new ArrayList<String>();
		originChannels.add("portalB2B".toUpperCase());
		originChannels.add("vivoNow".toUpperCase());
		originChannels.add("SFA".toUpperCase());
		return originChannels;
	}

}
