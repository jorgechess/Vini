package br.com.tlf.dip.infrasctructure.rest.vivonow;

import br.com.tlf.dip.core.port.out.VivoNowArchivePortOut;
import br.com.tlf.dip.infrasctructure.rest.vivonow.feign.archive.VivoNowArchiveClient;
import br.com.tlf.dip.infrasctructure.rest.vivonow.feign.archive.dto.VivoNowAttachmentResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VivoNowArchivePortOutImpl implements VivoNowArchivePortOut {

    @Autowired
    VivoNowArchiveClient client;

    @Override
    public VivoNowAttachmentResponseDTO attachFile(String fileName, String tableName, String tableSysId, String authorization, byte[] file) {
        return client.attachFile(fileName, tableName, tableSysId, authorization, file);
    }
}
