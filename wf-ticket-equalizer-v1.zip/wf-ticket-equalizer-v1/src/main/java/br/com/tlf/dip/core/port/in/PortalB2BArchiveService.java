package br.com.tlf.dip.core.port.in;

import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketRequestDTO;
import br.com.tlf.dip.core.port.in.dto.AttachmentFileTicketResponseDTO;

public interface PortalB2BArchiveService {

	AttachmentFileTicketResponseDTO attachFilePortalB2B(String authorization, 
			AttachmentFileTicketRequestDTO attachmentFileTicketRequestDTO);

}
