package br.com.tlf.dip.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "camunda")
public class CamundaProperties {

	private String urlSignatureAuthentication;
	private String urlApi;

	public String getUrlSignatureAuthentication() {
		return urlSignatureAuthentication;
	}

	public void setUrlSignatureAuthentication(String urlSignatureAuthentication) {
		this.urlSignatureAuthentication = urlSignatureAuthentication;
	}

	public String getUrlApi() {
		return urlApi;
	}

	public void setUrlApi(String urlApi) {
		this.urlApi = urlApi;
	}

}