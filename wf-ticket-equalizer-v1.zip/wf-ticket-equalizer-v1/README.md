# Como utilizar este projeto  

Se você estiver o Maven na sua máquina, basta entrar no terminal e digitar o seguinte comando

```bash
mvn install
```

Caso não tenha o Maven instalado na sua máquina, utilize o portátil localizado na raiz do seu projeto.

Para Windows, abra o terminal na raiz do projeto e utilize o seguinte comando:

```bash
mvnw.cmd install
```

Para Linux:   

```bash
mvnw install
```

Caso ele não funcione no seu terminal do Linux, utilize o comando **chmod +x mvnw** e então tente rodar o comando acima novamente.